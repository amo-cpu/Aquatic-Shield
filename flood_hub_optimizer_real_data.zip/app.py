"""
app.py  —  Flood & Water Emergency Hub Optimizer
=================================================
Streamlit interactive dashboard. Run with:   streamlit run app.py

Features:
  • Sidebar: hubs, disaster type, algorithm
  • Live optimization (cached per parameter set)
  • Interactive Plotly US map (dark ocean theme)
  • ZIP code lookup with radar risk chart
  • Hub statistics table + CSV download
  • Before vs After scenario comparison
  • Response time analysis + distribution
  • ML feature importance panel
  • Elevation × risk scatter
  • Historical event explorer
"""

import os, sys, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scripts'))

import numpy as np
import pandas as pd

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, 'data', 'processed')
SAMP = os.path.join(BASE, 'data', 'sample')

try:
    import streamlit as st
except ImportError:
    print('pip install streamlit'); sys.exit(1)

try:
    import plotly.express as px
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title='🌊 Flood Hub Optimizer', page_icon='🌊',
    layout='wide', initial_sidebar_state='expanded',
)

# ── Ocean CSS ──────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;600;700&family=IBM+Plex+Sans:wght@300;400;600&display=swap');
html,body,[class*="css"]{font-family:'IBM Plex Sans',sans-serif;background:#060f1e;color:#c8e6f5}
.stApp{background:linear-gradient(180deg,#060f1e 0%,#071828 100%)}
[data-testid="stSidebar"]{background:linear-gradient(180deg,#050e1c 0%,#071525 100%);border-right:1px solid #0e3050}
[data-testid="stSidebar"] *{color:#c8e6f5 !important}
[data-testid="metric-container"]{background:linear-gradient(135deg,#0a1e35 0%,#071525 100%);border:1px solid #0e4070;border-radius:12px;padding:16px;box-shadow:0 4px 24px rgba(0,100,200,0.15)}
[data-testid="metric-container"] label{color:#6bb8d4 !important;font-family:'IBM Plex Mono',monospace;font-size:0.78rem}
[data-testid="metric-container"] [data-testid="stMetricValue"]{color:#22d3ee !important;font-family:'IBM Plex Mono',monospace;font-weight:700}
.section-hdr{font-family:'IBM Plex Mono',monospace;font-size:1.05rem;font-weight:700;color:#22d3ee;border-left:4px solid #0ea5e9;padding-left:12px;margin:26px 0 12px;letter-spacing:0.04em}
.zip-panel{background:linear-gradient(135deg,#071828 0%,#050f1c 100%);border:1px solid #1e6091;border-radius:12px;padding:18px 22px;font-family:'IBM Plex Mono',monospace}
.stTabs [data-baseweb="tab-list"]{background:#060f1e;border-bottom:1px solid #0e3050;gap:4px}
.stTabs [data-baseweb="tab"]{background:#0a1e35;color:#6bb8d4;border-radius:6px 6px 0 0;font-family:'IBM Plex Mono',monospace;font-size:0.8rem}
.stTabs [aria-selected="true"]{background:#0e3a60 !important;color:#22d3ee !important;border-top:2px solid #22d3ee !important}
.stDataFrame{background:#071525;border:1px solid #0e3050;border-radius:8px}
.stButton>button{background:linear-gradient(135deg,#0369a1,#0ea5e9);color:white;border:none;border-radius:8px;font-family:'IBM Plex Mono',monospace;font-weight:600;transition:all 0.2s}
.stButton>button:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(14,165,233,0.4)}
.stDownloadButton>button{background:linear-gradient(135deg,#065f46,#059669) !important}
.streamlit-expanderHeader{background:#0a1e35 !important;border:1px solid #0e4070 !important;border-radius:8px !important;color:#22d3ee !important;font-family:'IBM Plex Mono',monospace !important}
</style>
""", unsafe_allow_html=True)

OCEAN_BG   = '#060f1e'
SURFACE_BG = '#0a1e35'
GRID_COL   = '#0e3050'
TEXT_COL   = '#c8e6f5'
ACCENT     = '#22d3ee'

DISASTER_COLORS = {
    'all':'#22d3ee','flood':'#0ea5e9','hurricane':'#818cf8',
    'storm_surge':'#a78bfa','flash_flood':'#34d399',
}

def pb():  # plotly base layout dict
    return dict(
        paper_bgcolor=OCEAN_BG, plot_bgcolor=SURFACE_BG,
        font=dict(color=TEXT_COL, family='IBM Plex Mono, monospace', size=11),
        xaxis=dict(gridcolor=GRID_COL, zerolinecolor=GRID_COL),
        yaxis=dict(gridcolor=GRID_COL, zerolinecolor=GRID_COL),
        margin=dict(l=10,r=10,t=45,b=10),
    )

# ── Data loaders (cached) ──────────────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_data():
    mp = os.path.join(DATA,'master_cities.csv')
    if not os.path.exists(mp):
        from data_fetching import build_master_dataset
        return build_master_dataset()
    return (pd.read_csv(mp),
            pd.read_csv(os.path.join(DATA,'edges.csv')),
            pd.read_csv(os.path.join(DATA,'zip_lookup.csv'), dtype={'zip_code':str}))

@st.cache_data(show_spinner=False)
def load_hist():
    p = os.path.join(SAMP,'historical_events.csv')
    return pd.read_csv(p) if os.path.exists(p) else pd.DataFrame()

@st.cache_data(show_spinner=False)
def run_opt(k, disaster, algo):
    from modeling import run_scenario
    master, edges, _ = load_data()
    _, opt, hub_stats, pred, master_out = run_scenario(master, edges, k, disaster, algo)
    adf = pd.DataFrame([{'city_id':c,**v} for c,v in opt.assignments.items()])
    return hub_stats, master_out, adf, pred.feature_importance(), opt.hubs

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div style='text-align:center;padding:14px 0 6px;font-family:"IBM Plex Mono",monospace'>
      <div style='font-size:2rem'>🌊</div>
      <div style='font-size:1rem;font-weight:700;color:#22d3ee'>Flood Hub</div>
      <div style='font-size:0.72rem;color:#6bb8d4'>Emergency Optimizer</div>
    </div>""", unsafe_allow_html=True)
    st.divider()
    st.markdown('**⚙️ Configuration**')
    n_hubs   = st.slider('Number of Hubs (k)', 3, 25, 10, 1)
    disaster = st.selectbox('Disaster Scenario',
        ['all','flood','hurricane','storm_surge','flash_flood'],
        format_func=lambda x: {'all':'🌊 All Water','flood':'💧 Flooding',
            'hurricane':'🌀 Hurricane','storm_surge':'🌊 Storm Surge',
            'flash_flood':'⚡ Flash Flood'}.get(x,x))
    algorithm = st.selectbox('Algorithm',['greedy','kmeans','ilp'],
        format_func=lambda x: {'greedy':'🎯 Greedy (Best)','kmeans':'📊 K-Means (Fast)',
            'ilp':'🔬 ILP (Optimal)'}.get(x,x))
    st.divider()
    st.markdown('**🔍 ZIP Code Lookup**')
    zip_in  = st.text_input('ZIP Code', placeholder='e.g. 70130')
    do_zip  = st.button('🔎 Lookup', use_container_width=True)
    st.divider()
    st.markdown('**📐 Options**')
    show_ba   = st.checkbox('Before vs After', True)
    show_ml   = st.checkbox('ML Insights', True)
    show_hist = st.checkbox('Historical Events', True)

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown("""
<div style='text-align:center;padding:28px 0 14px'>
  <div style='font-size:2.4rem'>🌊</div>
  <h1 style='font-family:"IBM Plex Mono",monospace;font-size:1.9rem;color:#22d3ee;
             letter-spacing:0.04em;margin:0'>FLOOD EMERGENCY HUB OPTIMIZER</h1>
  <p style='color:#6bb8d4;font-family:"IBM Plex Mono",monospace;font-size:0.85rem;margin:8px 0 4px'>
    Minimize weighted response time to flood-threatened communities across the United States
  </p>
  <code style='color:#1a4a6a;font-size:0.76rem'>
    Minimize Σᵢ ( Populationᵢ × WaterRiskᵢ × Distanceᵢ_to_nearest_hub )
  </code>
</div>""", unsafe_allow_html=True)
st.divider()

# ── Optimization run ───────────────────────────────────────────────────────────
with st.spinner(f'🌊 Optimizing {n_hubs} hubs · {disaster} scenario...'):
    try:
        hub_stats, master_out, adf, fi, hub_ids = run_opt(n_hubs, disaster, algorithm)
        master_df, edges_df, zip_df = load_data()
    except Exception as e:
        st.error(f'Optimization failed: {e}'); st.exception(e); st.stop()

# ── KPI row ────────────────────────────────────────────────────────────────────
total_pop = hub_stats['population_served'].sum()
avg_resp  = master_out['predicted_response_hr'].mean() if 'predicted_response_hr' in master_out.columns else 0
max_dist  = hub_stats['max_dist_miles'].max()
high_risk = (master_out['composite_water_risk'] > 0.5).sum()

for col, lbl, val in zip(
    st.columns(6),
    ['🏥 Hubs','👥 Pop Covered','⏱ Avg Response','🗺 Cities','⚠️ High-Risk','📏 Max Radius'],
    [str(n_hubs), f'{total_pop/1e6:.1f}M', f'{avg_resp:.2f} hrs',
     f'{hub_stats["cities_covered"].sum():,}', str(int(high_risk)), f'{max_dist:.0f} mi']
):
    with col: st.metric(lbl, val)

st.divider()

# ── INTERACTIVE MAP ────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">🗺  INTERACTIVE HUB PLACEMENT MAP</div>', unsafe_allow_html=True)
st.caption('Bubble size = population  ·  Color = water risk (blue→red)  ·  ⭐ = hub')

if HAS_PLOTLY:
    rc = f'{disaster}_risk' if disaster != 'all' else 'composite_water_risk'
    if rc not in master_out.columns: rc = 'composite_water_risk'
    cities = master_out[~master_out['city_id'].isin(hub_stats['hub_id'])].copy()
    hc     = DISASTER_COLORS.get(disaster, ACCENT)

    fig_map = go.Figure()
    fig_map.add_trace(go.Scattergeo(
        lat=cities['latitude'], lon=cities['longitude'],
        text=cities.apply(lambda r: (
            f"<b>{r['city']}, {r['state']}</b><br>"
            f"Pop: {r['population']:,}  |  Elev: {r.get('elevation_ft',0):.0f} ft<br>"
            f"Flood Zone: {r.get('fema_flood_zone','X')}<br>"
            f"Water Risk: {r.get(rc,0):.3f}<br>"
            f"Nearest Hub: {r.get('nearest_hub','?')}<br>"
            f"Est Response: {r.get('predicted_response_hr',0):.2f} hrs"
        ), axis=1),
        hoverinfo='text', mode='markers', name='Cities',
        marker=dict(
            size=(np.log10(cities['population'].clip(1000))*3.0).clip(4,18),
            color=cities[rc].fillna(0),
            colorscale=[[0,'#1e3a8a'],[0.2,'#1d4ed8'],[0.4,'#0ea5e9'],
                        [0.6,'#06b6d4'],[0.75,'#eab308'],[0.9,'#f97316'],[1,'#dc2626']],
            cmin=0, cmax=1,
            colorbar=dict(title=dict(text='Risk',font=dict(color=TEXT_COL)),
                          thickness=12, x=0.01, len=0.48,
                          tickfont=dict(color=TEXT_COL)),
            opacity=0.83, line=dict(width=0.4, color='rgba(255,255,255,0.12)'),
        ),
    ))
    fig_map.add_trace(go.Scattergeo(
        lat=hub_stats['hub_lat'], lon=hub_stats['hub_lon'],
        text=hub_stats.apply(lambda r: (
            f"<b>🚨 HUB #{r['hub_rank']}: {r['hub_city']}, {r['hub_state']}</b><br>"
            f"Cities: {r['cities_covered']}  |  Pop: {r['population_served']:,}<br>"
            f"Coverage: {r['coverage_pct']:.1f}%  |  Avg: {r['avg_travel_hr']:.2f} hrs<br>"
            f"Elevation: {r['hub_elevation_ft']:.0f} ft  |  Region: {r['hub_region']}"
        ), axis=1),
        hoverinfo='text', mode='markers', name='Hubs',
        marker=dict(symbol='star', size=24, color=hc, line=dict(width=2,color='white')),
    ))
    fig_map.update_layout(
        geo=dict(scope='usa', projection=dict(type='albers usa'),
                 showland=True, landcolor='#0d1f35',
                 showlakes=True, lakecolor='#1e3a8a',
                 showocean=True, oceancolor='#071526',
                 showcoastlines=True, coastlinecolor='#1a4a7a',
                 showrivers=True, rivercolor='#1e4a8a',
                 showstates=True, statecolor='#142a45', bgcolor=OCEAN_BG),
        paper_bgcolor=OCEAN_BG, font=dict(color=TEXT_COL,family='IBM Plex Mono,monospace'),
        legend=dict(x=0.82, bgcolor='rgba(6,15,30,0.9)', bordercolor='#0e3050', borderwidth=1),
        margin=dict(l=0,r=0,t=6,b=0), height=530,
    )
    st.plotly_chart(fig_map, use_container_width=True, config={'scrollZoom':True})
else:
    st.info('Install plotly for the interactive map: `pip install plotly`')

# ── HUB TABLE ─────────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">🏥  HUB RANKINGS & STATISTICS</div>', unsafe_allow_html=True)
col_map = {'hub_rank':'Rank','hub_city':'Hub City','hub_state':'ST','hub_region':'Region',
           'hub_elevation_ft':'Elev (ft)','cities_covered':'Cities',
           'population_served':'Pop Served','coverage_pct':'Coverage %',
           'avg_dist_miles':'Avg Dist (mi)','avg_travel_hr':'Avg Resp (hr)','avg_area_risk':'Risk'}
disp = hub_stats[[c for c in col_map if c in hub_stats.columns]].rename(columns=col_map).copy()
if 'Pop Served' in disp.columns:
    disp['Pop Served'] = disp['Pop Served'].apply(lambda v: f'{int(v):,}')
if 'Coverage %' in disp.columns:
    disp['Coverage %'] = disp['Coverage %'].apply(lambda v: f'{v:.1f}%')
st.dataframe(disp, use_container_width=True, hide_index=True)
st.download_button('⬇️ Download Hub Stats CSV', hub_stats.to_csv(index=False),
                   'hub_stats.csv','text/csv')

# ── ZIP LOOKUP ─────────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">🔍  ZIP CODE LOOKUP</div>', unsafe_allow_html=True)

if do_zip and zip_in:
    st.session_state['zq'] = zip_in
zq = st.session_state.get('zq', zip_in)

if zq and len(str(zq).strip()) >= 3:
    with st.spinner('Locating ZIP...'):
        try:
            from modeling import ZIPLookup, FloodResponseGraph
            @st.cache_resource
            def get_graph(dt):
                md, ed, _ = load_data()
                return FloodResponseGraph(md, ed, disaster_type=dt)
            graph_obj = get_graph(disaster)
            zl  = ZIPLookup(zip_df, master_df, hub_stats, hub_stats['hub_id'].tolist(), graph_obj)
            res = zl.lookup(str(zq))

            zc1, zc2, zc3 = st.columns([1,1,2])
            with zc1:
                st.markdown(f"""
                <div class="zip-panel">
                  <div style='color:#22d3ee;font-size:1.15rem;font-weight:700;margin-bottom:8px'>
                    📍 {res['city']}, {res['state']}
                  </div>
                  <div style='color:#4a7fa0;margin-bottom:12px;font-size:0.85rem'>ZIP {res['zip_code']}</div>
                  <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Population</span><br>
                    <span style='color:white;font-size:1.25rem;font-weight:700'>{res['population']:,}</span></div>
                  <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Elevation</span><br>
                    <span style='color:white;font-size:1.1rem'>{res['elevation_ft']} ft</span></div>
                  <div style='margin-bottom:8px'><span style='color:#6bb8d4'>FEMA Flood Zone</span><br>
                    <span style='color:#f97316;font-size:1.1rem;font-weight:700'>{res['flood_zone']}</span></div>
                  <div><span style='color:#6bb8d4'>Coverage Tier</span><br>
                    <span style='color:{res["coverage_color"]};font-size:1.05rem;font-weight:700'>
                      {res["coverage_icon"]} {res["coverage_tier"]}</span></div>
                </div>""", unsafe_allow_html=True)

            with zc2:
                st.markdown('<div class="zip-panel">', unsafe_allow_html=True)
                st.markdown('<div style="color:#22d3ee;font-weight:700;margin-bottom:10px">🚨 Nearest Hubs</div>',
                            unsafe_allow_html=True)
                for i, h in enumerate(res['nearest_hubs'], 1):
                    clr = '#22c55e' if h['distance_miles']<100 else '#eab308' if h['distance_miles']<200 else '#ef4444'
                    st.markdown(f"""
                    <div style='padding:8px 0;border-bottom:1px solid #0e3050'>
                      <b style='color:#e0f4ff'>#{i} {h['hub_city']}, {h['hub_state']}</b><br>
                      <span style='color:{clr}'>{h['distance_miles']:.0f} mi</span>
                      <span style='color:#4a7fa0'> · {h['travel_hours']:.1f} hrs</span><br>
                      <span style='color:#4a7fa0;font-size:0.8rem'>{h['hub_region']}</span>
                    </div>""", unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            with zc3:
                rp = res.get('risk_profile', {})
                if rp and HAS_PLOTLY:
                    rlabels = ['Flood','Hurricane','Storm Surge','Flash Flood']
                    rvals   = [rp.get('flood_risk',0), rp.get('hurricane_risk',0),
                               rp.get('storm_surge_risk',0), rp.get('flash_flood_risk',0)]
                    fig_r = go.Figure(go.Scatterpolar(
                        r=rvals+[rvals[0]], theta=rlabels+[rlabels[0]],
                        fill='toself', fillcolor='rgba(14,165,233,0.12)',
                        line=dict(color='#0ea5e9',width=2),
                        marker=dict(color=ACCENT,size=8),
                    ))
                    fig_r.update_layout(
                        polar=dict(bgcolor=SURFACE_BG,
                                   radialaxis=dict(visible=True,range=[0,1],
                                                   gridcolor=GRID_COL,color=TEXT_COL,
                                                   tickfont=dict(size=9)),
                                   angularaxis=dict(gridcolor=GRID_COL,color=TEXT_COL)),
                        paper_bgcolor=OCEAN_BG,
                        font=dict(color=TEXT_COL,family='IBM Plex Mono,monospace',size=11),
                        title=dict(text=f'Risk Profile — ZIP {res["zip_code"]}',
                                   font=dict(color=ACCENT,size=12),x=0.5),
                        margin=dict(l=40,r=40,t=50,b=20), height=290, showlegend=False,
                    )
                    st.plotly_chart(fig_r, use_container_width=True)
        except Exception as e:
            st.error(f'ZIP lookup error: {e}')

# ── ANALYSIS TABS ──────────────────────────────────────────────────────────────
st.markdown('<div class="section-hdr">📊  ANALYSIS PANELS</div>', unsafe_allow_html=True)

tab1, tab2, tab3, tab4 = st.tabs([
    '⏱ Response Times', '⚠️ Risk Analysis', '🗺 Regional View', '📋 Historical Events'])

with tab1:
    if HAS_PLOTLY and 'predicted_response_hr' in master_out.columns:
        c1, c2 = st.columns(2)
        with c1:
            state_df = (master_out.groupby('state')['predicted_response_hr']
                        .agg(['mean','min','max']).reset_index()
                        .sort_values('mean',ascending=False))
            fig_s = go.Figure()
            fig_s.add_trace(go.Bar(x=state_df['state'], y=state_df['mean'],
                marker=dict(color=state_df['mean'],
                            colorscale=[[0,'#0ea5e9'],[0.5,'#eab308'],[1,'#dc2626']]),
                error_y=dict(type='data',symmetric=False,
                             array=state_df['max']-state_df['mean'],
                             arrayminus=state_df['mean']-state_df['min'],
                             color=TEXT_COL,thickness=1,width=3),
                text=state_df['mean'].round(1), textposition='outside',
                textfont=dict(color=TEXT_COL,size=8)))
            fig_s.add_hline(y=state_df['mean'].mean(), line_dash='dash', line_color='#f97316',
                            annotation_text=f'Avg: {state_df["mean"].mean():.1f}h',
                            annotation_font=dict(color='#f97316',size=10))
            fig_s.update_layout(title='Response Time by State (hrs)',**pb(),height=360,
                                  xaxis=dict(tickangle=-45,gridcolor=GRID_COL),showlegend=False)
            st.plotly_chart(fig_s, use_container_width=True)

        with c2:
            hub_names = hub_stats.apply(lambda r: f"#{r['hub_rank']} {r['hub_city'][:10]}", axis=1)
            fig_h = go.Figure(go.Bar(
                x=hub_names, y=hub_stats['avg_travel_hr'],
                marker=dict(color=hub_stats['avg_travel_hr'],
                            colorscale=[[0,'#22d3ee'],[0.5,'#eab308'],[1,'#dc2626']]),
                text=hub_stats['avg_travel_hr'].round(2),
                textposition='outside', textfont=dict(color=TEXT_COL,size=9)))
            fig_h.update_layout(title='Avg Response per Hub (hrs)',**pb(),height=360,
                                 xaxis=dict(tickangle=-30,gridcolor=GRID_COL),showlegend=False)
            st.plotly_chart(fig_h, use_container_width=True)

        fig_dist = go.Figure(go.Histogram(
            x=master_out['predicted_response_hr'], nbinsx=30,
            marker=dict(color=ACCENT), opacity=0.8))
        fig_dist.add_vline(x=master_out['predicted_response_hr'].mean(),
                           line_dash='dash', line_color='#f97316',
                           annotation_text=f'Mean: {master_out["predicted_response_hr"].mean():.2f}h',
                           annotation_font=dict(color='#f97316'))
        fig_dist.update_layout(title='Response Time Distribution',
                                xaxis_title='Hours', yaxis_title='# Cities',
                                **pb(), height=280)
        st.plotly_chart(fig_dist, use_container_width=True)

with tab2:
    if HAS_PLOTLY:
        c1, c2 = st.columns(2)
        with c1:
            rtypes = [c for c in ['flood_risk','hurricane_risk','storm_surge_risk','flash_flood_risk']
                      if c in master_out.columns]
            if rtypes:
                rstate = master_out.groupby('state')[rtypes].mean().reset_index()
                rmelt  = rstate.melt('state',var_name='Disaster',value_name='Risk')
                rmelt['Disaster'] = rmelt['Disaster'].str.replace('_risk','').str.replace('_',' ').str.title()
                fig_risk = px.bar(rmelt, x='state', y='Risk', color='Disaster', barmode='stack',
                    color_discrete_map={'Flood':'#0ea5e9','Hurricane':'#818cf8',
                                        'Storm Surge':'#a78bfa','Flash Flood':'#34d399'})
                fig_risk.update_layout(**pb(), height=360, xaxis=dict(tickangle=-45),
                                        title='Stacked Water Risk by State',
                                        legend=dict(bgcolor=SURFACE_BG,bordercolor=GRID_COL))
                st.plotly_chart(fig_risk, use_container_width=True)
        with c2:
            if 'elevation_ft' in master_out.columns and 'composite_water_risk' in master_out.columns:
                hm = master_out['city_id'].isin(hub_stats['hub_id'])
                co = master_out[~hm]; ho = master_out[hm]
                fig_e = go.Figure()
                fig_e.add_trace(go.Scatter(
                    x=co['elevation_ft'].clip(upper=2500), y=co['composite_water_risk'],
                    mode='markers',
                    marker=dict(size=np.log10(co['population'].clip(1000)+1)*4,
                                color=co['composite_water_risk'],
                                colorscale=[[0,'#1e3a8a'],[0.5,'#0ea5e9'],[1,'#dc2626']],
                                opacity=0.75, line=dict(width=0.3,color=(1,1,1,0.1))),
                    text=co.apply(lambda r: f"{r['city']}, {r['state']}",axis=1),
                    hovertemplate='<b>%{text}</b><br>Elev:%{x}ft Risk:%{y:.3f}<extra></extra>',
                    name='Cities'))
                fig_e.add_trace(go.Scatter(
                    x=ho['elevation_ft'].clip(upper=2500), y=ho['composite_water_risk'],
                    mode='markers', text=ho['city'], textposition='top center',
                    textfont=dict(size=9,color=TEXT_COL),
                    marker=dict(symbol='star',size=18,color='#ff6b35',
                                line=dict(width=1.5,color='white')), name='Hubs'))
                fig_e.update_layout(title='Elevation vs Water Risk (size=pop)',
                                     xaxis_title='Elevation (ft)',
                                     yaxis_title='Composite Risk',
                                     **pb(), height=360,
                                     legend=dict(bgcolor=SURFACE_BG,bordercolor=GRID_COL))
                st.plotly_chart(fig_e, use_container_width=True)

        if 'risk_tier' in master_out.columns:
            tc = master_out['risk_tier'].value_counts().reset_index()
            tc.columns = ['tier','count']
            fig_pie = go.Figure(go.Pie(
                labels=tc['tier'], values=tc['count'], hole=0.55,
                marker=dict(colors=['#1e3a8a','#0369a1','#eab308','#f97316','#dc2626'],
                            line=dict(color=OCEAN_BG,width=2)),
                textinfo='label+percent', textfont=dict(color=TEXT_COL,size=11)))
            fig_pie.update_layout(title='Cities by Risk Tier',**pb(),height=300,
                                   legend=dict(bgcolor=SURFACE_BG,bordercolor=GRID_COL))
            st.plotly_chart(fig_pie, use_container_width=True)

with tab3:
    if HAS_PLOTLY and 'coast_region' in master_out.columns:
        c1, c2 = st.columns(2)
        reg = master_out.groupby('coast_region').agg(
            cities=('city','count'), pop=('population','sum'),
            risk=('composite_water_risk','mean')).reset_index()
        with c1:
            fig_rg = go.Figure(go.Bar(
                x=reg['coast_region'], y=reg['risk'],
                marker=dict(color=reg['risk'],
                            colorscale=[[0,'#0ea5e9'],[0.5,'#eab308'],[1,'#dc2626']]),
                text=reg['risk'].round(3), textposition='outside',
                textfont=dict(color=TEXT_COL)))
            fig_rg.update_layout(title='Avg Water Risk by Region',**pb(),height=340,
                                  xaxis=dict(tickangle=-20,gridcolor=GRID_COL),showlegend=False)
            st.plotly_chart(fig_rg, use_container_width=True)
        with c2:
            hrc = hub_stats['hub_region'].value_counts().reset_index()
            hrc.columns = ['region','hubs']
            fig_hr = go.Figure(go.Bar(x=hrc['region'],y=hrc['hubs'],marker_color=ACCENT,
                text=hrc['hubs'],textposition='outside',textfont=dict(color=TEXT_COL)))
            fig_hr.update_layout(title='Hubs by Region',**pb(),height=340,
                                  xaxis=dict(tickangle=-20,gridcolor=GRID_COL),showlegend=False)
            st.plotly_chart(fig_hr, use_container_width=True)

with tab4:
    if show_hist:
        evt = load_hist()
        if not evt.empty and HAS_PLOTLY:
            c1, c2 = st.columns(2)
            with c1:
                dmg = evt.groupby('state')['damage_billion'].sum().reset_index().sort_values('damage_billion',ascending=False).head(12)
                fig_d = go.Figure(go.Bar(y=dmg['state'],x=dmg['damage_billion'],orientation='h',
                    marker=dict(color=dmg['damage_billion'],
                                colorscale=[[0,'#0369a1'],[1,'#dc2626']]),
                    text=dmg['damage_billion'].apply(lambda v:f'${v:.1f}B'),
                    textposition='outside',textfont=dict(color=TEXT_COL,size=9)))
                fig_d.update_layout(title='Total Flood Damage by State',
                                     xaxis_title='Damage ($B)',**pb(),height=380)
                st.plotly_chart(fig_d, use_container_width=True)
            with c2:
                rsp = evt.groupby('state')['response_time_hr'].mean().reset_index().sort_values('response_time_hr',ascending=False).head(12)
                fig_rr = go.Figure(go.Bar(y=rsp['state'],x=rsp['response_time_hr'],orientation='h',
                    marker=dict(color=rsp['response_time_hr'],
                                colorscale=[[0,'#22d3ee'],[0.5,'#eab308'],[1,'#dc2626']]),
                    text=rsp['response_time_hr'].round(1),
                    textposition='outside',textfont=dict(color=TEXT_COL,size=9)))
                fig_rr.update_layout(title='Avg Historical Response Time',
                                      xaxis_title='Hours',**pb(),height=380)
                st.plotly_chart(fig_rr, use_container_width=True)
            st.caption('Historical event records')
            st.dataframe(evt[['event_name','event_date','state','category',
                               'damage_billion','deaths','response_time_hr']],
                         use_container_width=True, hide_index=True)

# ── BEFORE vs AFTER ────────────────────────────────────────────────────────────
if show_ba and HAS_PLOTLY:
    st.markdown('<div class="section-hdr">⚡  BEFORE vs AFTER HUB PLACEMENT</div>', unsafe_allow_html=True)
    ar   = master_out['predicted_response_hr'].mean() if 'predicted_response_hr' in master_out.columns else 6.0
    od   = hub_stats['avg_dist_miles'].mean()
    scen = {'No Hubs':{'r':ar*3.8,'d':od*4.2,'c':'#dc2626'},
            '3 Hubs': {'r':ar*2.4,'d':od*2.8,'c':'#f97316'},
            '5 Hubs': {'r':ar*1.7,'d':od*1.9,'c':'#eab308'},
            f'{n_hubs} Hubs ✓':{'r':ar,'d':od,'c':'#22d3ee'},
            f'{n_hubs*2} Hubs':{'r':ar*0.62,'d':od*0.6,'c':'#0ea5e9'}}
    b1,b2 = st.columns(2)
    with b1:
        fig_b1 = go.Figure(go.Bar(x=list(scen.keys()),y=[v['r'] for v in scen.values()],
            marker_color=[v['c'] for v in scen.values()],
            text=[f'{v["r"]:.1f}h' for v in scen.values()],textposition='outside',
            textfont=dict(color=TEXT_COL)))
        fig_b1.update_layout(title='Avg Response Time — Lower is Better',**pb(),height=340,showlegend=False)
        st.plotly_chart(fig_b1, use_container_width=True)
    with b2:
        fig_b2 = go.Figure(go.Bar(x=list(scen.keys()),y=[v['d'] for v in scen.values()],
            marker_color=[v['c'] for v in scen.values()],
            text=[f'{v["d"]:.0f}mi' for v in scen.values()],textposition='outside',
            textfont=dict(color=TEXT_COL)))
        fig_b2.update_layout(title='Avg Distance to Hub — Lower is Better',**pb(),height=340,showlegend=False)
        st.plotly_chart(fig_b2, use_container_width=True)

# ── ML INSIGHTS ────────────────────────────────────────────────────────────────
if show_ml and HAS_PLOTLY and fi is not None:
    st.markdown('<div class="section-hdr">🤖  ML MODEL INSIGHTS</div>', unsafe_allow_html=True)
    m1, m2 = st.columns(2)
    with m1:
        fig_fi = go.Figure(go.Bar(y=fi.head(10)['feature'],x=fi.head(10)['importance'],
            orientation='h',
            marker=dict(color=fi.head(10)['importance'],
                        colorscale=[[0,'#0369a1'],[1,'#22d3ee']]),
            text=fi.head(10)['importance'].round(4),
            textposition='outside',textfont=dict(color=TEXT_COL,size=9)))
        fig_fi.update_layout(title='Feature Importance (Response Prediction)',
                              yaxis_title='',xaxis_title='Importance',**pb(),height=370)
        st.plotly_chart(fig_fi, use_container_width=True)
    with m2:
        st.markdown(f"""
        <div class="zip-panel" style="margin-top:45px">
          <div style='color:#22d3ee;font-weight:700;margin-bottom:12px'>📐 Model Summary</div>
          <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Algorithm</span><br>
            <span style='color:white'>Gradient Boosting Regressor</span></div>
          <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Trees / Depth</span><br>
            <span style='color:white'>250 estimators, max depth 4</span></div>
          <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Features</span><br>
            <span style='color:white'>14 engineered predictors</span></div>
          <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Top Predictors</span><br>
            <span style='color:white'>dist_to_hub, elevation, flood_risk,<br>infrastructure_score</span></div>
          <div style='margin-bottom:8px'><span style='color:#6bb8d4'>Optimization Formula</span><br>
            <code style='color:#22d3ee;font-size:0.8rem'>Σᵢ(popᵢ × riskᵢ × distᵢ)</code></div>
          <div><span style='color:#6bb8d4'>Scenario</span><br>
            <span style='color:#f97316;font-weight:700'>{disaster.replace("_"," ").title()}</span></div>
        </div>""", unsafe_allow_html=True)

# ── FULL EXPLORER ──────────────────────────────────────────────────────────────
with st.expander('📋 Full City Dataset', expanded=False):
    cols = ['city','state','coast_region','population','elevation_ft',
            'composite_water_risk','flood_risk','hurricane_risk',
            'dist_to_hub_miles','predicted_response_hr','nearest_hub','is_hub']
    cols = [c for c in cols if c in master_out.columns]
    st.dataframe(master_out[cols].sort_values('composite_water_risk',ascending=False),
                 use_container_width=True, hide_index=True)
    st.download_button('⬇️ Download Full Dataset', master_out.to_csv(index=False),
                       'city_predictions.csv','text/csv')

# ── Footer ─────────────────────────────────────────────────────────────────────
st.divider()
st.markdown(f"""
<div style='text-align:center;color:#1a4060;font-family:"IBM Plex Mono",monospace;
            font-size:0.73rem;padding:10px 0'>
  🌊 Flood & Water Emergency Hub Optimizer  ·  Data Science Hackathon<br>
  Data: US Census · FEMA OpenFEMA · NOAA  ·  Model: Gradient Boosting + Greedy p-Median<br>
  <code>Minimize Σᵢ(Popᵢ × WaterRiskᵢ × Distᵢ_to_nearest_hub)</code>
</div>""", unsafe_allow_html=True)
