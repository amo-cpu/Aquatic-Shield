#!/usr/bin/env python3
"""
run_all.py
==========
One-shot script that runs the entire pipeline and generates all outputs.

Usage:
    python run_all.py                         # Default: 10 hubs, flood scenario
    python run_all.py --hubs 15 --disaster all
    python run_all.py --hubs 8  --disaster hurricane --algorithm kmeans
    python run_all.py --quick                 # Skip visualizations for fast demo

Outputs:
    data/processed/          — merged datasets
    outputs/tables/          — hub_stats.csv, city_assignments.csv
    outputs/maps/            — Folium + Plotly HTML maps
    outputs/charts/          — PNG charts + Plotly dashboards
    dashboard/               — Standalone HTML dashboard
    outputs/reports/         — Summary report
"""

import os, sys, time, argparse
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'scripts'))

BASE = os.path.dirname(os.path.abspath(__file__))

def run(cmd):
    import subprocess
    result = subprocess.run(cmd, shell=True, capture_output=False, text=True)
    return result.returncode == 0

def section(title):
    print(f'\n{"━"*62}')
    print(f'  {title}')
    print(f'{"━"*62}')

def main():
    parser = argparse.ArgumentParser(description='Flood Hub Optimizer — Full Pipeline')
    parser.add_argument('--hubs',       type=int, default=10)
    parser.add_argument('--disaster',   type=str, default='flood',
                        choices=['all','flood','hurricane','storm_surge','flash_flood'])
    parser.add_argument('--algorithm',  type=str, default='greedy',
                        choices=['greedy','kmeans','ilp'])
    parser.add_argument('--quick',      action='store_true',
                        help='Skip slower visualizations')
    args = parser.parse_args()

    t0 = time.time()
    print('\n' + '═'*62)
    print('  🌊 FLOOD EMERGENCY HUB OPTIMIZER — FULL PIPELINE')
    print('═'*62)
    print(f'  Hubs: {args.hubs}  |  Disaster: {args.disaster}  |  Algorithm: {args.algorithm}')

    # ── Step 1: Sample data ──────────────────────────────────────────────────
    section('STEP 1/5 — Generating Sample Datasets')
    if not os.path.exists(os.path.join(BASE, 'data/sample/cities.csv')):
        ok = run(f'python {BASE}/scripts/generate_sample_data.py')
        if not ok: print('  ⚠ Sample data generation failed'); sys.exit(1)
    else:
        print('  ✓ Sample data already exists — skipping generation')

    # ── Step 2: Data pipeline ────────────────────────────────────────────────
    section('STEP 2/5 — Data Fetching & Merging')
    ok = run(f'python {BASE}/scripts/data_fetching.py')
    if not ok: print('  ⚠ Data pipeline failed'); sys.exit(1)

    # ── Step 3: Modeling ─────────────────────────────────────────────────────
    section('STEP 3/5 — Hub Optimization & ML Prediction')
    ok = run(f'python {BASE}/scripts/modeling.py '
             f'--hubs {args.hubs} --disaster {args.disaster} '
             f'--algorithm {args.algorithm} --save')
    if not ok: print('  ⚠ Modeling failed'); sys.exit(1)

    # ── Step 4: Visualizations ───────────────────────────────────────────────
    if not args.quick:
        section('STEP 4/5 — Generating Visualizations')
        ok = run(f'python {BASE}/scripts/visualization.py '
                 f'--hubs {args.hubs} --disaster {args.disaster}')
        if not ok: print('  ⚠ Some visualizations failed (non-fatal)')
    else:
        print('\n  [Quick mode] Skipping visualization generation')

    # ── Step 5: Build standalone dashboard ───────────────────────────────────
    section('STEP 5/5 — Building Standalone HTML Dashboard')
    try:
        import json, numpy as np, pandas as pd

        master   = pd.read_csv(os.path.join(BASE, 'outputs/tables/city_assignments.csv'))
        hubs     = pd.read_csv(os.path.join(BASE, 'outputs/tables/hub_stats.csv'))
        fi       = pd.read_csv(os.path.join(BASE, 'outputs/tables/feature_importance.csv'))
        hist     = pd.read_csv(os.path.join(BASE, 'data/sample/historical_events.csv'))

        city_cols = ['city_id','city','state','coast_region','latitude','longitude',
                     'population','elevation_ft','composite_water_risk','flood_risk',
                     'hurricane_risk','storm_surge_risk','flash_flood_risk',
                     'risk_tier','fema_flood_zone','is_hub','nearest_hub',
                     'dist_to_hub_miles','predicted_response_hr']
        city_cols = [c for c in city_cols if c in master.columns]

        bundle = {
            'cities':        master[city_cols].fillna(0).to_dict('records'),
            'hubs':          hubs.fillna(0).to_dict('records'),
            'feature_imp':   fi.head(12).to_dict('records'),
            'state_resp':    master.groupby('state')['predicted_response_hr'].mean().round(2).to_dict(),
            'state_risk':    master.groupby('state')['composite_water_risk'].mean().round(3).to_dict(),
            'region_data':   master.groupby('coast_region').agg(
                                 cities=('city','count'), pop=('population','sum'),
                                 risk=('composite_water_risk','mean')
                             ).reset_index().round(3).to_dict('records'),
            'dmg_by_state':  hist.groupby('state')['damage_billion'].sum().round(2).to_dict(),
            'resp_by_state': hist.groupby('state')['response_time_hr'].mean().round(1).to_dict(),
        }

        class NpEncoder(json.JSONEncoder):
            def default(self, obj):
                if isinstance(obj, (np.integer,)):   return int(obj)
                if isinstance(obj, (np.floating,)):  return float(obj)
                return super().default(obj)

        template = os.path.join(BASE, 'dashboard/dashboard_template.html')
        if os.path.exists(template):
            with open(template) as f:
                html = f.read()
            html = html.replace('__DATA_PLACEHOLDER__', json.dumps(bundle, cls=NpEncoder))
            out_path = os.path.join(BASE, 'dashboard/flood_hub_dashboard.html')
            with open(out_path, 'w') as f:
                f.write(html)
            print(f'  ✓ Dashboard: {out_path}')
        else:
            print('  ⚠ dashboard_template.html not found — skipping dashboard build')

    except Exception as e:
        print(f'  ⚠ Dashboard build failed: {e}')

    # ── Summary report ───────────────────────────────────────────────────────
    section('PIPELINE COMPLETE')
    elapsed = time.time() - t0
    print(f'  Total time: {elapsed:.1f}s\n')

    try:
        hub_stats = pd.read_csv(os.path.join(BASE,'outputs/tables/hub_stats.csv'))
        master    = pd.read_csv(os.path.join(BASE,'outputs/tables/city_assignments.csv'))
        print(f'  Hubs placed       : {len(hub_stats)}')
        print(f'  Population covered: {hub_stats["population_served"].sum():,.0f}')
        print(f'  Avg response time : {master["predicted_response_hr"].mean():.2f} hrs')
        print(f'  Avg dist to hub   : {master["dist_to_hub_miles"].mean():.1f} mi')
        print(f'  Highest risk hub  : {hub_stats.loc[hub_stats["avg_area_risk"].idxmax(),"hub_city"]}')
    except Exception:
        pass

    print('\n  📁 Output files:')
    for dirpath, dirnames, filenames in os.walk(os.path.join(BASE,'outputs')):
        for fn in filenames:
            fp = os.path.join(dirpath, fn)
            sz = os.path.getsize(fp)
            relpath = os.path.relpath(fp, BASE)
            print(f'    {relpath:<55} ({sz//1024} KB)')
    print(f'\n    {"dashboard/flood_hub_dashboard.html":<55} (standalone)')

    print('\n  🚀 Next steps:')
    print('    Streamlit:  streamlit run app.py')
    print('    Browser:    open dashboard/flood_hub_dashboard.html')
    print('    Notebook:   jupyter notebook notebooks/flood_hub_demo.ipynb')


if __name__ == '__main__':
    import pandas  # ensure available before entering main
    main()
