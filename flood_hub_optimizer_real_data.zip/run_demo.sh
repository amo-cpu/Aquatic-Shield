#!/usr/bin/env bash
# ============================================================
# run_demo.sh — Flood Hub Optimizer  |  One-command hackathon demo
# ============================================================
# Usage:
#   chmod +x run_demo.sh
#   ./run_demo.sh              # full pipeline + dashboard
#   ./run_demo.sh --no-app     # pipeline only (no streamlit)
#   ./run_demo.sh --hubs 15    # override hub count

set -e

HUBS=10
DISASTER="flood"
ALGORITHM="greedy"
LAUNCH_APP=true

# Parse args
while [[ $# -gt 0 ]]; do
    case "$1" in
        --hubs)      HUBS="$2";      shift 2 ;;
        --disaster)  DISASTER="$2";  shift 2 ;;
        --algorithm) ALGORITHM="$2"; shift 2 ;;
        --no-app)    LAUNCH_APP=false; shift ;;
        *) shift ;;
    esac
done

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  🌊  FLOOD & WATER EMERGENCY HUB OPTIMIZER           ║"
echo "║      Hackathon Data Science Track                    ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""
echo "  Config: hubs=$HUBS | disaster=$DISASTER | algo=$ALGORITHM"
echo ""

# Step 1: Generate sample data
echo "[1/4] Generating sample datasets..."
python scripts/generate_sample_data.py
echo ""

# Step 2: Data pipeline
echo "[2/4] Running data pipeline..."
python scripts/data_fetching.py
echo ""

# Step 3: Optimization + ML
echo "[3/4] Optimizing hub placement (greedy, flood scenario)..."
python scripts/modeling.py \
    --hubs "$HUBS" \
    --disaster "$DISASTER" \
    --algorithm "$ALGORITHM" \
    --save
echo ""

# Step 4: Visualizations
echo "[4/4] Generating visualizations..."
python scripts/visualization.py \
    --hubs "$HUBS" \
    --disaster "$DISASTER" \
    --algorithm "$ALGORITHM"
echo ""

echo "╔══════════════════════════════════════════════════════╗"
echo "║  ✅  Pipeline complete!  Output files:               ║"
echo "║     outputs/maps/      — interactive maps (HTML)     ║"
echo "║     outputs/charts/    — charts (PNG + HTML)         ║"
echo "║     outputs/tables/    — CSV result tables           ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

if [ "$LAUNCH_APP" = true ]; then
    echo "  🚀 Launching Streamlit dashboard..."
    echo "     URL: http://localhost:8501"
    echo "     Press Ctrl+C to stop"
    echo ""
    streamlit run app.py \
        --server.headless true \
        --server.port 8501 \
        --browser.gatherUsageStats false
fi
