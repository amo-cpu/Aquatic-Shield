"""
data_fetching.py
================
Downloads, validates, cleans, and merges all datasets for the
Flood & Water Emergency Hub Optimizer.

Live data sources (uncomment --live flag to attempt real fetches):
  • US Census Bureau ACS 5-year population estimates
  • OpenFEMA Disaster Declarations API
  • NOAA Storm Events API
  • NWS Flood Risk Products

Falls back to rich sample data if network is unavailable.

Usage:
  python scripts/data_fetching.py              # use sample data
  python scripts/data_fetching.py --live       # attempt live APIs
  python scripts/data_fetching.py --state FL   # single-state subset
"""

import os, sys, argparse, warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from math import radians, sin, cos, sqrt, atan2

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SAMPLE  = os.path.join(BASE, 'data', 'sample')
PROC    = os.path.join(BASE, 'data', 'processed')
os.makedirs(PROC, exist_ok=True)

# ── Disaster type → risk column mapping ───────────────────────────────────────
DISASTER_RISK_COL = {
    'flood':         'flood_risk',
    'hurricane':     'hurricane_risk',
    'storm_surge':   'storm_surge_risk',
    'flash_flood':   'flash_flood_risk',
    'all':           'composite_water_risk',
}

# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────────────────────
def haversine_miles(lat1, lon1, lat2, lon2):
    """Great-circle distance in miles between two lat/lon points."""
    R = 3958.8
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2-lat1, lon2-lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return R * 2 * atan2(sqrt(a), sqrt(1-a))


def road_travel_hours(dist_miles, road_type='US Highway'):
    """Estimate road travel time from straight-line distance.
    Applies road-factor (roads are longer than Haversine) + speed assumption."""
    speed_mph = {'Interstate': 65, 'US Highway': 52, 'State Road': 37}.get(road_type, 52)
    road_factor = {'Interstate': 1.18, 'US Highway': 1.32, 'State Road': 1.48}.get(road_type, 1.32)
    return (dist_miles * road_factor) / speed_mph


# ─────────────────────────────────────────────────────────────────────────────
# LOADERS
# ─────────────────────────────────────────────────────────────────────────────
def load_cities(live=False, state=None):
    """Load city geolocation + population. Optionally filter to one state."""
    if live:
        try:
            print('  → Fetching Census ACS5 population API...')
            url = ('https://api.census.gov/data/2021/acs/acs5'
                   '?get=NAME,B01003_001E&for=place:*&in=state:*')
            df = pd.read_json(url)
            df.columns = df.iloc[0]
            df = df[1:].rename(columns={'NAME':'city','B01003_001E':'population'})
            df['population'] = pd.to_numeric(df['population'], errors='coerce')
            df = df[df['population'] > 5000]
            print(f'  ✓ Census API: {len(df)} cities')
        except Exception as e:
            print(f'  ⚠ Census API failed ({e}), using sample data')
            live = False

    if not live:
        df = pd.read_csv(os.path.join(SAMPLE, 'cities.csv'))
        print(f'  ✓ Sample cities: {len(df)} rows')

    if state:
        df = df[df['state'] == state.upper()]
        print(f'  → Filtered to state={state}: {len(df)} cities')

    required = ['city_id','city','state','latitude','longitude','population']
    missing  = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f'Missing required columns: {missing}')

    return df.reset_index(drop=True)


def load_flood_risk(live=False):
    """Load FEMA/NOAA flood risk scores. Returns per-city risk DataFrame."""
    if live:
        try:
            print('  → Fetching OpenFEMA disaster declarations...')
            url = ('https://www.fema.gov/api/open/v2/disasterDeclarationsSummaries'
                   '?$select=state,disasterType,declarationDate&$top=2000')
            df = pd.read_json(url)
            print(f'  ✓ FEMA API: {len(df)} records (needs processing)')
        except Exception as e:
            print(f'  ⚠ FEMA API failed ({e}), using sample data')
            live = False

    if not live:
        df = pd.read_csv(os.path.join(SAMPLE, 'flood_risk.csv'))
        print(f'  ✓ Sample flood_risk: {len(df)} rows')

    return df


def load_zip_data():
    df = pd.read_csv(os.path.join(SAMPLE, 'zip_lookup.csv'), dtype={'zip_code': str})
    df['zip_code'] = df['zip_code'].str.zfill(5)
    print(f'  ✓ ZIP lookup: {len(df)} ZIPs')
    return df


def load_road_distances():
    df = pd.read_csv(os.path.join(SAMPLE, 'road_distances.csv'))
    print(f'  ✓ Road distances: {len(df)} edges')
    return df


def load_historical_events():
    df = pd.read_csv(os.path.join(SAMPLE, 'historical_events.csv'))
    print(f'  ✓ Historical events: {len(df)} records')
    return df


def load_fema_declarations():
    df = pd.read_csv(os.path.join(SAMPLE, 'fema_declarations.csv'))
    print(f'  ✓ FEMA declarations: {len(df)} states')
    return df


# ─────────────────────────────────────────────────────────────────────────────
# MASTER DATASET BUILDER
# ─────────────────────────────────────────────────────────────────────────────
def build_master_dataset(live=False, state=None):
    """
    Merge all datasets into a single master DataFrame ready for modeling.

    Processing pipeline:
      1. Load cities (geo + population)
      2. Load flood risk scores
      3. Load FEMA state-level context
      4. Load historical events → aggregate by state
      5. Merge all → feature engineering
      6. Load road edges → filter to cities in master
      7. Save processed files

    Returns:
        master_df  : pd.DataFrame — one row per city, all features
        edges_df   : pd.DataFrame — road graph edges
        zip_df     : pd.DataFrame — ZIP code lookup table
    """
    print('\n[1/6] Loading cities...')
    cities = load_cities(live=live, state=state)

    print('[2/6] Loading flood risk...')
    risk = load_flood_risk(live=live)

    print('[3/6] Loading FEMA declarations...')
    fema = load_fema_declarations()

    print('[4/6] Loading historical events...')
    events = load_historical_events()

    # Aggregate historical events by state
    evt_agg = events.groupby('state').agg(
        total_damage_B  = ('damage_billion','sum'),
        avg_response_hr = ('response_time_hr','mean'),
        total_claims    = ('nfip_claims','sum'),
        event_count     = ('event_name','count'),
    ).reset_index()

    print('[5/6] Merging datasets...')

    # Merge cities + risk
    if 'city_id' in risk.columns:
        master = cities.merge(
            risk.drop(columns=['city','state','coast_region'], errors='ignore'),
            on='city_id', how='left'
        )
    else:
        master = cities.copy()

    # Merge FEMA state data
    master = master.merge(
        fema[['state','flood_declarations_2000_2024','avg_mobilize_time_hr',
              'pre_positioned_supplies','total_fema_grants_M']],
        on='state', how='left'
    )

    # Merge historical event aggregates
    master = master.merge(evt_agg, on='state', how='left')

    # ── Feature engineering ───────────────────────────────────────────────────
    # 1. Weighted population (core objective function node weight)
    #    w_i = pop_i × (1 + composite_water_risk_i)
    risk_col = master.get('composite_water_risk', pd.Series(0.1, index=master.index))
    if 'composite_water_risk' in master.columns:
        master['weighted_population'] = (
            master['population'] * (1 + master['composite_water_risk'])
        ).round(0).astype(int)
    else:
        master['composite_water_risk'] = 0.1
        master['weighted_population']  = master['population']

    # 2. Elevation vulnerability (lower elevation → higher vulnerability)
    master['elevation_vulnerability'] = (
        1 / (1 + master['elevation_ft'].clip(lower=1) / 100)
    ).round(4)

    # 3. Normalized node weight for visualization sizing
    max_wp = master['weighted_population'].max()
    master['node_weight'] = (master['weighted_population'] / max_wp).round(4)

    # 4. Risk tier categorization
    master['risk_tier'] = pd.cut(
        master['composite_water_risk'],
        bins=[0, 0.20, 0.40, 0.60, 0.80, 1.01],
        labels=['Very Low','Low','Moderate','High','Very High'],
        include_lowest=True
    )

    # Fill remaining NAs
    fill_vals = {
        'composite_water_risk': 0.05,
        'flood_risk':           0.05,
        'hurricane_risk':       0.00,
        'storm_surge_risk':     0.00,
        'flash_flood_risk':     0.10,
        'avg_response_hr':      24.0,
        'avg_mobilize_time_hr': 24.0,
        'total_damage_B':       0.0,
        'event_count':          0,
        'total_fema_grants_M':  0.0,
        'pre_positioned_supplies': 0,
        'infrastructure_score': 0.6,
        'levee_protected':      0,
        'elevation_ft':         100,
    }
    for col, val in fill_vals.items():
        if col in master.columns:
            master[col] = master[col].fillna(val)

    print(f'  ✓ Master dataset: {len(master)} cities, {len(master.columns)} features')

    print('[6/6] Loading & filtering road edges...')
    edges_all  = load_road_distances()
    zip_df     = load_zip_data()

    valid_ids  = set(master['city_id'])
    edges      = edges_all[
        edges_all['from_city_id'].isin(valid_ids) &
        edges_all['to_city_id'].isin(valid_ids)
    ].copy().reset_index(drop=True)
    print(f'  ✓ Edges filtered: {len(edges)} (from {len(edges_all)} total)')

    # Save processed outputs
    master.to_csv(os.path.join(PROC, 'master_cities.csv'), index=False)
    edges.to_csv(os.path.join(PROC, 'edges.csv'), index=False)
    zip_df.to_csv(os.path.join(PROC, 'zip_lookup.csv'), index=False)
    print(f'\n  Saved → data/processed/master_cities.csv')
    print(f'  Saved → data/processed/edges.csv')
    print(f'  Saved → data/processed/zip_lookup.csv')

    return master, edges, zip_df


# ─────────────────────────────────────────────────────────────────────────────
# SUMMARY PRINTER
# ─────────────────────────────────────────────────────────────────────────────
def print_data_summary(master, edges, zip_df):
    print('\n' + '═'*58)
    print('  FLOOD HUB OPTIMIZER — DATA SUMMARY')
    print('═'*58)
    print(f'  Cities/nodes       : {len(master):>7,}')
    print(f'  Road edges         : {len(edges):>7,}')
    print(f'  ZIP codes          : {len(zip_df):>7,}')
    print(f'  Total population   : {master["population"].sum():>14,.0f}')
    print(f'  States covered     : {master["state"].nunique():>7}')
    print(f'  Avg composite risk : {master["composite_water_risk"].mean():>9.3f}')
    print(f'  Highest risk city  : {master.loc[master["composite_water_risk"].idxmax(),"city"]}')
    print(f'  Lowest elevation   : {master.loc[master["elevation_ft"].idxmin(),"city"]} '
          f'({master["elevation_ft"].min()} ft)')
    print()
    print('  Risk tier breakdown:')
    if 'risk_tier' in master.columns:
        for tier, cnt in master['risk_tier'].value_counts().sort_index().items():
            bar = '█' * int(cnt / len(master) * 30)
            print(f'    {str(tier):<12} {bar:<30} {cnt:>4}')
    print('═'*58)


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Flood Hub Optimizer — Data Pipeline')
    parser.add_argument('--live',  action='store_true', help='Attempt live API fetches')
    parser.add_argument('--state', type=str, default=None, help='Filter to one state (e.g. FL)')
    args = parser.parse_args()

    print('━'*58)
    print('  FLOOD & WATER EMERGENCY HUB OPTIMIZER')
    print('  Data Fetching & Processing Pipeline')
    print('━'*58)

    master, edges, zip_df = build_master_dataset(live=args.live, state=args.state)
    print_data_summary(master, edges, zip_df)

    print('\n✅ Data pipeline complete.')
    print('   Next → python scripts/modeling.py --hubs 10 --disaster flood')
