"""
generate_sample_data.py
=======================
Generates all sample datasets for the Flood & Water Emergency Hub Optimizer.
Run this FIRST to populate data/sample/ before any other scripts.

Outputs:
  data/sample/cities.csv             — US cities with lat/lon, population
  data/sample/flood_risk.csv         — Flood/hurricane/storm risk by city
  data/sample/zip_lookup.csv         — ZIP-code level population & coords
  data/sample/road_distances.csv     — City-pair travel distances & times
  data/sample/historical_events.csv  — Historical flood damage records
  data/sample/fema_declarations.csv  — FEMA disaster declarations by state
"""

import os
import numpy as np
import pandas as pd
from math import radians, sin, cos, sqrt, atan2

np.random.seed(2024)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'data', 'sample')
os.makedirs(OUT, exist_ok=True)

# ─────────────────────────────────────────────────────────────────────────────
# REGION & RISK HELPERS
# ─────────────────────────────────────────────────────────────────────────────
GULF_COAST    = ['TX','LA','MS','AL','FL']
ATLANTIC      = ['FL','GA','SC','NC','VA','MD','DE','NJ','NY','CT','RI','MA','NH','ME']
INLAND_FLOOD  = ['MO','AR','TN','KY','OH','IN','IL','IA','MN','ND','SD','NE','KS','OK','WV','PA']
PACIFIC_COAST = ['CA','OR','WA']
GREAT_LAKES   = ['MI','WI','MN','OH','PA','NY','IL','IN']

def classify_coast(state):
    if state in GULF_COAST:    return 'Gulf Coast'
    if state in ATLANTIC:      return 'Atlantic Coast'
    if state in PACIFIC_COAST: return 'Pacific Coast'
    if state in GREAT_LAKES:   return 'Great Lakes'
    if state in INLAND_FLOOD:  return 'Inland River'
    return 'Low Risk'

def flood_base(state):
    if state in ['LA','FL','MS']:           return np.random.uniform(0.65, 0.95)
    if state in ['TX','AL','GA','SC','NC']: return np.random.uniform(0.50, 0.80)
    if state in ['VA','MD','NJ','NY']:      return np.random.uniform(0.40, 0.70)
    if state in ['MO','AR','TN','KY']:      return np.random.uniform(0.35, 0.65)
    if state in ['CA','OR','WA']:           return np.random.uniform(0.25, 0.55)
    if state in ['OH','IL','IA','IN']:      return np.random.uniform(0.25, 0.50)
    return np.random.uniform(0.05, 0.30)

def hurricane_base(state):
    if state in GULF_COAST:                return np.random.uniform(0.55, 0.90)
    if state in ['GA','SC','NC','VA','MD']: return np.random.uniform(0.30, 0.60)
    if state in ['NY','NJ','CT','RI','MA']: return np.random.uniform(0.20, 0.45)
    return np.random.uniform(0.00, 0.10)

def storm_surge_base(state):
    if state in ['LA','FL','MS','AL']:      return np.random.uniform(0.60, 0.92)
    if state in ['TX','GA','SC','NC']:      return np.random.uniform(0.40, 0.75)
    if state in ['VA','MD','NJ','NY']:      return np.random.uniform(0.25, 0.55)
    if state in ['CA','OR','WA']:           return np.random.uniform(0.10, 0.30)
    return np.random.uniform(0.00, 0.08)

# ─────────────────────────────────────────────────────────────────────────────
# 1. CITIES  (100 US cities with elevation data for flood modeling)
# ─────────────────────────────────────────────────────────────────────────────
CITY_DATA = [
    # name, state, lat, lon, population, elevation_ft
    ('New York',        'NY', 40.7128, -74.0060, 8336817,  33),
    ('Los Angeles',     'CA', 34.0522,-118.2437, 3979576, 233),
    ('Chicago',         'IL', 41.8781, -87.6298, 2693976, 594),
    ('Houston',         'TX', 29.7604, -95.3698, 2320268,  43),
    ('Philadelphia',    'PA', 39.9526, -75.1652, 1584064,  39),
    ('San Antonio',     'TX', 29.4241, -98.4936, 1547253, 650),
    ('San Diego',       'CA', 32.7157,-117.1611, 1423851,  62),
    ('Dallas',          'TX', 32.7767, -96.7970, 1343573, 430),
    ('Jacksonville',    'FL', 30.3322, -81.6557,  911507,  16),
    ('Fort Worth',      'TX', 32.7555, -97.3308,  909585, 653),
    ('Columbus',        'OH', 39.9612, -82.9988,  898553, 902),
    ('Charlotte',       'NC', 35.2271, -80.8431,  885708, 751),
    ('Indianapolis',    'IN', 39.7684, -86.1581,  876384, 715),
    ('San Francisco',   'CA', 37.7749,-122.4194,  873965,  52),
    ('Seattle',         'WA', 47.6062,-122.3321,  753675, 350),
    ('Denver',          'CO', 39.7392,-104.9903,  715522,5280),
    ('Nashville',       'TN', 36.1627, -86.7816,  689447, 597),
    ('Oklahoma City',   'OK', 35.4676, -97.5164,  655057,1201),
    ('Washington',      'DC', 38.9072, -77.0369,  705749,  14),
    ('Las Vegas',       'NV', 36.1699,-115.1398,  651319,2001),
    ('Louisville',      'KY', 38.2527, -85.7585,  633045, 489),
    ('Memphis',         'TN', 35.1495, -90.0490,  651073, 337),
    ('Portland',        'OR', 45.5051,-122.6750,  652503,  50),
    ('Baltimore',       'MD', 39.2904, -76.6122,  593490,  33),
    ('Kansas City',     'MO', 39.0997, -94.5786,  495327, 910),
    ('Atlanta',         'GA', 33.7490, -84.3880,  498715,1050),
    ('Omaha',           'NE', 41.2565, -95.9345,  486051,1090),
    ('Raleigh',         'NC', 35.7796, -78.6382,  467665, 315),
    ('Virginia Beach',  'VA', 36.8529, -75.9780,  459470,  12),
    ('Minneapolis',     'MN', 44.9778, -93.2650,  429606, 815),
    ('Tampa',           'FL', 27.9506, -82.4572,  399700,  48),
    ('New Orleans',     'LA', 29.9511, -90.0715,  383997,  -6),
    ('Wichita',         'KS', 37.6872, -97.3301,  389255,1299),
    ('Miami',           'FL', 25.7617, -80.1918,  442241,   6),
    ('Corpus Christi',  'TX', 27.8006, -97.3964,  326586,  35),
    ('Lexington',       'KY', 38.0406, -84.5037,  323780, 979),
    ('St. Louis',       'MO', 38.6270, -90.1994,  301578, 466),
    ('Pittsburgh',      'PA', 40.4406, -79.9959,  302407, 760),
    ('Baton Rouge',     'LA', 30.4515, -91.1871,  220236,  56),
    ('Richmond',        'VA', 37.5407, -77.4360,  230436, 166),
    ('Mobile',          'AL', 30.6954, -88.0399,  187041,  10),
    ('Shreveport',      'LA', 32.5252, -93.7502,  187593, 180),
    ('Galveston',       'TX', 29.3013, -94.7977,   47743,   7),
    ('Pensacola',       'FL', 30.4213, -87.2169,   52703, 105),
    ('Charleston',      'SC', 32.7765, -79.9311,  136208,  20),
    ('Savannah',        'GA', 32.0835, -81.0998,  144464,  43),
    ('Wilmington',      'NC', 34.2257, -77.9447,  123784,  38),
    ('Norfolk',         'VA', 36.8508, -76.2859,  242742,   6),
    ('Biloxi',          'MS', 30.3960, -88.8853,   46083,   2),
    ('Key West',        'FL', 24.5551, -81.7800,   25478,   5),
    ('Cape Coral',      'FL', 26.5629, -81.9495,  194016,   8),
    ('Fort Lauderdale', 'FL', 26.1224, -80.1373,  182437,   9),
    ('Fargo',           'ND', 46.8772, -96.7898,  125990, 900),
    ('Boise',           'ID', 43.6150,-116.2023,  235984,2704),
    ('Spokane',         'WA', 47.6588,-117.4260,  222081,1843),
    ('Little Rock',     'AR', 34.7465, -92.2896,  202591, 335),
    ('Jackson',         'MS', 32.2988, -90.1848,  166965, 298),
    ('Birmingham',      'AL', 33.5186, -86.8104,  212237, 600),
    ('Knoxville',       'TN', 35.9606, -83.9207,  187603, 889),
    ('Beaumont',        'TX', 30.0802, -94.1266,  117796,  24),
    ('Lake Charles',    'LA', 30.2266, -93.2174,   77989,  13),
    ('Houma',           'LA', 29.5958, -90.7195,   32476,  -4),
    ('Panama City',     'FL', 30.1588, -85.6602,   36877,  23),
    ('Daytona Beach',   'FL', 29.2108, -81.0228,   68104,  31),
    ('Sarasota',        'FL', 27.3364, -82.5307,   57738,  16),
    ('Myrtle Beach',    'SC', 33.6891, -78.8867,   35682,  23),
    ('Annapolis',       'MD', 38.9784, -76.4922,   40812,  11),
    ('Atlantic City',   'NJ', 39.3643, -74.4229,   37743,   7),
    ('Honolulu',        'HI', 21.3069,-157.8583,  347397,  23),
    ('Stockton',        'CA', 37.9577,-121.2908,  312697,  13),
    ('Sacramento',      'CA', 38.5816,-121.4944,  513624,  30),
    ('Tacoma',          'WA', 47.2529,-122.4443,  219346, 340),
    ('Portland',        'ME', 43.6591, -70.2568,   68408,  44),
    ('Providence',      'RI', 41.8240, -71.4128,  179883,  26),
    ('Hartford',        'CT', 41.7658, -72.6851,  121054,  18),
    ('Des Moines',      'IA', 41.5868, -93.6250,  214133, 948),
    ('Springfield',     'MO', 37.2090, -93.2923,  169176,1270),
    ('Chattanooga',     'TN', 35.0456, -85.3097,  179139, 676),
    ('Greenville',      'SC', 34.8526, -82.3940,   70635, 966),
    ('Lake Charles',    'LA', 30.2266, -93.2174,   77989,  13),
    ('Alexandria',      'LA', 31.3113, -92.4451,   47354,  90),
    ('Modesto',         'CA', 37.6391,-120.9969,  218464,  91),
    ('Eugene',          'OR', 44.0521,-123.0868,  176654, 422),
    ('Austin',          'TX', 30.2672, -97.7431,  978908, 489),
    ('Phoenix',         'AZ', 33.4484,-112.0740, 1680992,1086),
    ('Milwaukee',       'WI', 43.0389, -87.9065,  590157, 617),
    ('San Jose',        'CA', 37.3382,-121.8863, 1021795,  82),
    ('Albuquerque',     'NM', 35.0853,-106.6056,  564559,5312),
    ('Tucson',          'AZ', 32.2226,-110.9747,  542629,2389),
    ('Fresno',          'CA', 36.7378,-119.7871,  531576, 335),
    ('Long Beach',      'CA', 33.7701,-118.1937,  466742,  32),
    ('Colorado Springs','CO', 38.8339,-104.8214,  478961,6035),
    ('Aurora',          'CO', 39.7294,-104.8319,  386261,5471),
    ('Anaheim',         'CA', 33.8366,-117.9143,  346824, 160),
    ('Anchorage',       'AK', 61.2181,-149.9003,  288000, 144),
    ('El Paso',         'TX', 31.7619,-106.4850,  678815,3740),
    ('Mesa',            'AZ', 33.4152,-111.8315,  504258,1243),
    ('Arlington',       'TX', 32.7357, -97.1081,  398854, 616),
    ('Bakersfield',     'CA', 35.3733,-119.0187,  383579, 404),
    ('Riverside',       'CA', 33.9806,-117.3755,  331360, 820),
]

rows = []
for name, st, lat, lon, pop, elev in CITY_DATA:
    coast = classify_coast(st)
    rows.append({
        'city_id':            f"{name.replace(' ','_')}_{st}",
        'city':               name,
        'state':              st,
        'coast_region':       coast,
        'latitude':           lat,
        'longitude':          lon,
        'population':         pop,
        'elevation_ft':       elev,
        'population_density': round(pop / np.random.uniform(60, 800), 1),
        'median_income':      int(np.random.uniform(32000, 98000)),
        'hospitals':          max(1, int(pop/180000) + np.random.randint(0,4)),
        'fire_stations':      max(1, int(pop/45000)  + np.random.randint(0,6)),
        'coast_proximity_mi': max(0, round(
            np.random.uniform(0,200) if coast in ['Gulf Coast','Atlantic Coast','Pacific Coast']
            else np.random.uniform(80,600), 1)),
    })

df_cities = pd.DataFrame(rows).drop_duplicates(subset='city_id').reset_index(drop=True)
df_cities.to_csv(f'{OUT}/cities.csv', index=False)
print(f'✓ cities.csv — {len(df_cities)} cities')

# ─────────────────────────────────────────────────────────────────────────────
# 2. FLOOD / HURRICANE / STORM SURGE RISK
# ─────────────────────────────────────────────────────────────────────────────
risk_rows = []
for _, r in df_cities.iterrows():
    st   = r['state']
    elev = max(1, r['elevation_ft'])
    fl   = round(flood_base(st) * max(0.4, 1 - elev/6000), 3)
    hu   = round(hurricane_base(st), 3)
    ss   = round(storm_surge_base(st) * max(0.2, 1 - elev/800), 3)
    ff   = round(np.random.uniform(0.15,0.60) if r['coast_region'] == 'Inland River'
                 else np.random.uniform(0.05,0.35), 3)
    comp = round(0.35*fl + 0.30*hu + 0.25*ss + 0.10*ff, 3)
    risk_rows.append({
        'city_id':               r['city_id'],
        'city':                  r['city'],
        'state':                 r['state'],
        'coast_region':          r['coast_region'],
        'flood_risk':            fl,
        'hurricane_risk':        hu,
        'storm_surge_risk':      ss,
        'flash_flood_risk':      ff,
        'composite_water_risk':  comp,
        'fema_flood_zone':       np.random.choice(
                                   ['A','AE','AH','AO','V','VE','X','D'],
                                   p=[0.10,0.18,0.05,0.05,0.05,0.07,0.40,0.10]),
        'avg_annual_flood_days': round(comp * np.random.uniform(2,25), 1),
        'storm_surge_height_ft': round(ss * np.random.uniform(0,18), 1),
        'fema_declarations_10yr':int(comp * np.random.uniform(0,20)),
        'nfip_claims_per_1k':    round(comp * np.random.uniform(0,85), 1),
        'avg_damage_M_per_event':round(comp * np.random.uniform(5,500), 1),
        'infrastructure_score':  round(np.random.uniform(0.3, 1.0), 3),
        'levee_protected':       int(np.random.choice([0,1], p=[0.7,0.3])),
    })

df_risk = pd.DataFrame(risk_rows)
df_risk.to_csv(f'{OUT}/flood_risk.csv', index=False)
print(f'✓ flood_risk.csv — {len(df_risk)} rows')

# ─────────────────────────────────────────────────────────────────────────────
# 3. ZIP CODE LOOKUP TABLE
# ─────────────────────────────────────────────────────────────────────────────
zip_rows = []
zc = 10001
seen = set()
for _, cr in df_cities.iterrows():
    n_zips = max(1, min(9, int(np.log10(cr['population']+1)) - 1))
    for _ in range(n_zips):
        while zc in seen:
            zc += np.random.randint(1,60)
        seen.add(zc)
        frac = np.random.dirichlet(np.ones(n_zips))[0]
        sub  = max(800, int(cr['population'] * frac))
        dlat = np.random.uniform(-0.22, 0.22)
        dlon = np.random.uniform(-0.22, 0.22)
        zip_rows.append({
            'zip_code':    str(zc).zfill(5),
            'city':        cr['city'],
            'state':       cr['state'],
            'coast_region':cr['coast_region'],
            'latitude':    round(cr['latitude']  + dlat, 4),
            'longitude':   round(cr['longitude'] + dlon, 4),
            'population':  sub,
            'elevation_ft':max(0, cr['elevation_ft'] + int(np.random.normal(0,40))),
            'median_age':  round(np.random.uniform(27,55), 1),
            'housing_units':max(100, int(sub/2.4)),
            'flood_zone':  np.random.choice(['A','AE','X','V'], p=[0.15,0.20,0.55,0.10]),
        })
        zc += np.random.randint(10,250)

df_zip = pd.DataFrame(zip_rows)
df_zip.to_csv(f'{OUT}/zip_lookup.csv', index=False)
print(f'✓ zip_lookup.csv — {len(df_zip)} ZIPs')

# ─────────────────────────────────────────────────────────────────────────────
# 4. ROAD / TRAVEL DISTANCES
# ─────────────────────────────────────────────────────────────────────────────
def haversine(lat1,lon1,lat2,lon2):
    R = 3958.8
    lat1,lon1,lat2,lon2 = map(radians,[lat1,lon1,lat2,lon2])
    a = sin((lat2-lat1)/2)**2 + cos(lat1)*cos(lat2)*sin((lon2-lon1)/2)**2
    return R * 2 * atan2(sqrt(a), sqrt(1-a))

edge_rows = []
arr = df_cities[['city_id','city','state','latitude','longitude']].values
for i in range(len(arr)):
    for j in range(i+1, len(arr)):
        id1,c1,s1,la1,lo1 = arr[i]
        id2,c2,s2,la2,lo2 = arr[j]
        d = haversine(float(la1),float(lo1),float(la2),float(lo2))
        if d > 950: continue
        rf  = np.random.uniform(1.15, 1.52)
        spd = np.random.choice([62,50,36], p=[0.45,0.35,0.20])
        edge_rows.append({
            'from_city_id':           id1, 'to_city_id':   id2,
            'from_city':              c1,  'to_city':      c2,
            'distance_miles':         round(d*rf, 1),
            'travel_hours':           round(d*rf/spd, 3),
            'road_type':              np.random.choice(
                                        ['Interstate','US Highway','State Road'],
                                        p=[0.45,0.35,0.20]),
            'flood_vulnerable_segment': int(np.random.choice([0,1], p=[0.75,0.25])),
        })

df_edges = pd.DataFrame(edge_rows)
df_edges.to_csv(f'{OUT}/road_distances.csv', index=False)
print(f'✓ road_distances.csv — {len(df_edges)} edges')

# ─────────────────────────────────────────────────────────────────────────────
# 5. HISTORICAL FLOOD / HURRICANE EVENTS
# ─────────────────────────────────────────────────────────────────────────────
DISASTERS = {
    'Hurricane Katrina':    ('2005-08-29', ['LA','MS','AL','FL']),
    'Hurricane Harvey':     ('2017-08-25', ['TX','LA']),
    'Hurricane Ian':        ('2022-09-28', ['FL','SC','NC']),
    'Hurricane Ida':        ('2021-08-29', ['LA','MS','AL','NY','NJ']),
    'Hurricane Sandy':      ('2012-10-29', ['NJ','NY','CT','MD','VA']),
    'Mississippi Flood':    ('2011-05-01', ['MO','TN','MS','AR','LA']),
    'Hurricane Florence':   ('2018-09-14', ['NC','SC','VA']),
    'Midwest Floods':       ('2019-03-12', ['NE','IA','SD','MO','KS']),
    'Hurricane Michael':    ('2018-10-10', ['FL','GA','AL','NC']),
    'Baton Rouge Flood':    ('2016-08-12', ['LA']),
    'Hurricane Laura':      ('2020-08-27', ['LA','TX']),
    'Hurricane Delta':      ('2020-10-09', ['LA','TX']),
    'Hurricane Dorian':     ('2019-08-28', ['FL','NC','SC']),
    'Louisiana Floods':     ('2015-03-08', ['LA','TX','MS']),
    'South Carolina Flood': ('2015-10-04', ['SC','NC']),
}
event_rows = []
for event,(date,states) in DISASTERS.items():
    for st in states:
        event_rows.append({
            'event_name':           event,
            'event_date':           date,
            'state':                st,
            'category':             np.random.choice(
                                      ['Cat1','Cat2','Cat3','Cat4','Cat5','Major Flood'],
                                      p=[0.10,0.15,0.20,0.20,0.10,0.25]),
            'deaths':               int(np.random.exponential(28)),
            'injuries':             int(np.random.exponential(180)),
            'damage_billion':       round(np.random.exponential(7), 2),
            'homes_affected':       int(np.random.exponential(42000)),
            'response_time_hr':     round(np.random.uniform(4,96), 1),
            'fema_cost_M':          round(np.random.exponential(380), 1),
            'nfip_claims':          int(np.random.exponential(22000)),
            'max_surge_ft':         round(np.random.uniform(2,19), 1),
            'flood_extent_sqmi':    int(np.random.exponential(2800)),
        })

df_events = pd.DataFrame(event_rows)
df_events.to_csv(f'{OUT}/historical_events.csv', index=False)
print(f'✓ historical_events.csv — {len(df_events)} records')

# ─────────────────────────────────────────────────────────────────────────────
# 6. FEMA STATE-LEVEL DECLARATIONS
# ─────────────────────────────────────────────────────────────────────────────
states_all = sorted(set(df_cities['state'].tolist()))
fema_rows = []
for st in states_all:
    coast = classify_coast(st)
    base  = flood_base(st)
    fema_rows.append({
        'state':                      st,
        'coast_region':               coast,
        'flood_declarations_2000_2024': int(base * np.random.uniform(2,30)),
        'hurricane_declarations':       int(hurricane_base(st) * np.random.uniform(1,15)),
        'total_fema_grants_M':          round(base * np.random.uniform(10,2000), 1),
        'avg_mobilize_time_hr':         round(np.random.uniform(6,72), 1),
        'state_emergency_budget_M':     round(np.random.uniform(50,1500), 1),
        'pre_positioned_supplies':      int(np.random.choice([0,1,2,3], p=[0.30,0.30,0.25,0.15])),
        'mutual_aid_agreements':        int(np.random.randint(2,12)),
    })

df_fema = pd.DataFrame(fema_rows)
df_fema.to_csv(f'{OUT}/fema_declarations.csv', index=False)
print(f'✓ fema_declarations.csv — {len(df_fema)} states')

print('\n✅ All sample datasets generated in data/sample/')
print('   Next → python scripts/data_fetching.py')
