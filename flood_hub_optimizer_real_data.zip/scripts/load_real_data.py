"""
load_real_data.py — Load and merge real datasets from FEMA, Census, NOAA, USGS.

Real data sources:
  • US Cities lat/lon: Census 2021 Gazetteer (via GitHub gist)
  • Flood risk scores: FEMA NFIP claims + NOAA Atlas 14 + USGS NED
  • Hurricane risk: NOAA HURDAT2 track density + SLOSH surge zones
  • FEMA Declarations: OpenFEMA v2 DisasterDeclarationsSummaries (2000-2023)
  • Population: US Census ACS 2022 (city + county estimates)
  • Elevation: USGS National Elevation Dataset (NED 1/3 arc-second)
  • ZIP centroids: Census 2023 ZCTA Gazetteer

Usage:
    from scripts.load_real_data import load_real_datasets
    master_df, disasters_df, zips_df = load_real_datasets()
"""

import os
import pandas as pd
import numpy as np
from math import radians, cos, sin, asin, sqrt

# Paths
REAL_DIR = os.path.join(os.path.dirname(__file__), '..', 'data', 'real')


def haversine_km(lat1, lon1, lat2, lon2):
    """Haversine distance in km between two lat/lon points."""
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return 2 * R * asin(sqrt(a))


def load_real_datasets():
    """
    Load and merge all real datasets.
    Returns: (master_df, disasters_df, zips_df)
    """
    # ── 1. Master cities (cities + risk + population + elevation) ──────────
    master_path = os.path.join(REAL_DIR, 'master_cities.csv')
    master_df = pd.read_csv(master_path)
    print(f"[✓] Cities loaded: {len(master_df)} from Census Gazetteer 2021")

    # ── 2. FEMA disaster declarations ──────────────────────────────────────
    decl_path = os.path.join(REAL_DIR, 'fema_disaster_declarations.csv')
    disasters_df = pd.read_csv(decl_path, parse_dates=['declaration_date'])
    print(f"[✓] FEMA declarations: {len(disasters_df)} flood/hurricane events (2000-2023)")

    # ── 3. ZIP centroids ───────────────────────────────────────────────────
    zip_path = os.path.join(REAL_DIR, 'zip_centroids.csv')
    zips_df = pd.read_csv(zip_path, dtype={'zip_code': str})
    print(f"[✓] ZIP centroids: {len(zips_df)} ZCTAs from Census 2023 Gazetteer")

    # ── 4. County population ───────────────────────────────────────────────
    county_path = os.path.join(REAL_DIR, 'census_county_population.csv')
    counties_df = pd.read_csv(county_path)
    print(f"[✓] County population: {len(counties_df)} counties from Census ACS 2022")

    # ── 5. Merge FEMA disaster frequency into master ───────────────────────
    state_stats = disasters_df.groupby('state').agg(
        fema_decl_count=('disaster_number', 'count'),
        total_damage_B=('damage_billions', 'sum'),
        total_deaths=('deaths', 'sum'),
    ).reset_index()

    master_df = master_df.merge(state_stats, on='state', how='left')
    master_df['fema_decl_count'] = master_df['fema_decl_count'].fillna(15)
    master_df['total_damage_B'] = master_df['total_damage_B'].fillna(0)

    # ── 6. Weighted risk index (used in optimization objective) ────────────
    # Normalize FEMA declarations (max ~158 for TX)
    max_decl = master_df['fema_decl_count'].max()
    master_df['norm_fema'] = master_df['fema_decl_count'] / max_decl

    # Risk Index = weighted combination of all real risk signals
    master_df['risk_index'] = (
        0.40 * master_df['flood_risk'] +
        0.25 * master_df['hurricane_risk'] +
        0.20 * master_df['storm_surge_risk'] +
        0.15 * master_df['norm_fema']
    ).round(4)

    # ── 7. Optimization weight = population × risk ─────────────────────────
    master_df['opt_weight'] = (
        master_df['population'] * (1 + 2 * master_df['risk_index'])
    ).astype(int)

    print(f"\n[✓] Real data pipeline complete.")
    print(f"    Total population in dataset: {master_df['population'].sum():,.0f}")
    print(f"    Highest risk cities (risk_index):")
    top5 = master_df.nlargest(5, 'risk_index')[['city','state','risk_index','flood_risk','storm_surge_risk']]
    print(top5.to_string(index=False))

    return master_df, disasters_df, zips_df, counties_df


def build_edge_graph(master_df, max_edges_per_city=8):
    """
    Build road network edges using haversine distance.
    Only connects cities within 500km (approximate road connectivity).
    """
    cities = master_df[['city','state','latitude','longitude']].values
    n = len(cities)
    edges = []

    for i in range(n):
        distances = []
        for j in range(n):
            if i == j:
                continue
            d = haversine_km(
                float(cities[i][2]), float(cities[i][3]),
                float(cities[j][2]), float(cities[j][3])
            )
            if d < 500:
                distances.append((j, d))
        distances.sort(key=lambda x: x[1])
        for j, d in distances[:max_edges_per_city]:
            travel_hrs = d / 80.0  # ~80 km/h average road speed
            edges.append({
                'from_city': f"{cities[i][0]}_{cities[i][1]}",
                'to_city': f"{cities[j][0]}_{cities[j][1]}",
                'distance_km': round(d, 1),
                'travel_hours': round(travel_hrs, 2)
            })

    edges_df = pd.DataFrame(edges)
    out_path = os.path.join(REAL_DIR, 'road_edges.csv')
    edges_df.to_csv(out_path, index=False)
    print(f"[✓] Road edges built: {len(edges_df)} from haversine distances")
    return edges_df


if __name__ == '__main__':
    master_df, disasters_df, zips_df, counties_df = load_real_datasets()
    edges_df = build_edge_graph(master_df)

    # Save merged master
    out = os.path.join(REAL_DIR, 'master_merged.csv')
    master_df.to_csv(out, index=False)
    print(f"\n[✓] Merged master saved: {out}")
    print(master_df[['city','state','population','risk_index','opt_weight']].head(20).to_string())
