"""
modeling.py
===========
Core modeling engine for the Flood & Water Emergency Hub Optimizer.

Implements:
  1.  FloodResponseGraph  — NetworkX graph: cities as nodes, roads as edges,
                            weights = population × water-disaster risk
  2.  HubOptimizer        — Three algorithms:
        • Weighted K-Means  (fast MVP)
        • Greedy p-Median   (strong performance, recommended)
        • ILP via PuLP      (globally optimal, slower)
  3.  ResponseTimePredictor — Gradient Boosting ML model for risk-adjusted
                              response time prediction
  4.  ZIPLookup           — ZIP code query: nearest hubs, risk stats, coverage
  5.  ScenarioSimulator   — Compare hub placements across disaster scenarios

Usage:
  python scripts/modeling.py --hubs 12 --disaster flood --algorithm greedy
  python scripts/modeling.py --hubs 8  --disaster hurricane --algorithm kmeans
  python scripts/modeling.py --hubs 15 --disaster all --algorithm ilp --save
"""

import os, sys, json, argparse, warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
from math import radians, sin, cos, sqrt, atan2
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import cross_val_score
from sklearn.metrics import mean_squared_error
import networkx as nx

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(BASE, 'data', 'processed')
OUT  = os.path.join(BASE, 'outputs')
os.makedirs(os.path.join(OUT, 'tables'), exist_ok=True)
os.makedirs(os.path.join(OUT, 'reports'), exist_ok=True)

# ── Disaster scenario weights ──────────────────────────────────────────────────
# Define how much each risk type is weighted in the node weight calculation
SCENARIO_WEIGHTS = {
    'all':         {'flood':0.35, 'hurricane':0.30, 'storm_surge':0.25, 'flash_flood':0.10},
    'flood':       {'flood':0.75, 'hurricane':0.05, 'storm_surge':0.10, 'flash_flood':0.10},
    'hurricane':   {'flood':0.15, 'hurricane':0.65, 'storm_surge':0.15, 'flash_flood':0.05},
    'storm_surge': {'flood':0.10, 'hurricane':0.20, 'storm_surge':0.65, 'flash_flood':0.05},
    'flash_flood': {'flood':0.20, 'hurricane':0.05, 'storm_surge':0.05, 'flash_flood':0.70},
}

# Risk column map
RISK_COLS = {
    'flood':       'flood_risk',
    'hurricane':   'hurricane_risk',
    'storm_surge': 'storm_surge_risk',
    'flash_flood': 'flash_flood_risk',
}


# ─────────────────────────────────────────────────────────────────────────────
# UTILITY FUNCTIONS
# ─────────────────────────────────────────────────────────────────────────────
def haversine_miles(lat1, lon1, lat2, lon2):
    """Great-circle distance in statute miles."""
    R = 3958.8
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat, dlon = lat2-lat1, lon2-lon1
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    return R * 2 * atan2(sqrt(a), sqrt(1-a))


def travel_hours(dist_miles, road_type='US Highway', flood_penalty=False):
    """
    Convert distance to travel time.
    flood_penalty: adds 25-50% delay if road segment is flood-vulnerable.
    """
    speed = {'Interstate':65, 'US Highway':52, 'State Road':37}.get(road_type, 52)
    factor = {'Interstate':1.18,'US Highway':1.32,'State Road':1.48}.get(road_type, 1.32)
    base = (dist_miles * factor) / speed
    if flood_penalty:
        base *= np.random.uniform(1.25, 1.50)
    return base


# ═════════════════════════════════════════════════════════════════════════════
# 1. FLOOD RESPONSE GRAPH
# ═════════════════════════════════════════════════════════════════════════════
class FloodResponseGraph:
    """
    Represents the US as a weighted directed graph:
      Nodes  = cities (weighted by population × disaster-specific risk)
      Edges  = road connections (weighted by travel time in hours)

    Node weight formula:
        w_i = population_i × (1 + Σ_d scenario_weight_d × risk_d_i)

    This encodes the idea that a city with high population AND high disaster
    risk should be prioritized when placing emergency response hubs.
    """

    def __init__(self, master_df: pd.DataFrame, edges_df: pd.DataFrame,
                 disaster_type: str = 'all'):
        self.master       = master_df.copy()
        self.edges        = edges_df.copy()
        self.disaster     = disaster_type
        self.G            = nx.Graph()
        self.node_list    = []
        self._build()

    def _compute_node_weight(self, row) -> float:
        """
        Compute scenario-specific node weight.
        w_i = pop_i × (1 + Σ_d weight_d × risk_d_i)
        """
        weights = SCENARIO_WEIGHTS.get(self.disaster, SCENARIO_WEIGHTS['all'])
        risk_sum = sum(
            weights.get(d, 0) * float(row.get(RISK_COLS.get(d,''), 0) or 0)
            for d in ['flood','hurricane','storm_surge','flash_flood']
        )
        return float(row['population']) * (1.0 + risk_sum)

    def _build(self):
        """Build NetworkX graph from master dataset and edge list."""
        # Add nodes
        for _, row in self.master.iterrows():
            nw = self._compute_node_weight(row)
            attrs = {
                'city':               row['city'],
                'state':              row['state'],
                'lat':                float(row['latitude']),
                'lon':                float(row['longitude']),
                'population':         int(row['population']),
                'node_weight':        nw,
                'elevation_ft':       float(row.get('elevation_ft', 100)),
                'coast_region':       str(row.get('coast_region','Unknown')),
                'composite_water_risk': float(row.get('composite_water_risk',0)),
                'flood_risk':         float(row.get('flood_risk',0)),
                'hurricane_risk':     float(row.get('hurricane_risk',0)),
                'storm_surge_risk':   float(row.get('storm_surge_risk',0)),
                'flash_flood_risk':   float(row.get('flash_flood_risk',0)),
                'risk_tier':          str(row.get('risk_tier','Unknown')),
                'levee_protected':    int(row.get('levee_protected',0)),
                'infrastructure_score': float(row.get('infrastructure_score',0.6)),
            }
            self.G.add_node(row['city_id'], **attrs)

        self.node_list = list(self.G.nodes())

        # Add edges
        added = 0
        for _, e in self.edges.iterrows():
            if self.G.has_node(e['from_city_id']) and self.G.has_node(e['to_city_id']):
                flood_vuln = bool(e.get('flood_vulnerable_segment', 0))
                t_hours = travel_hours(
                    float(e['distance_miles']),
                    str(e.get('road_type','US Highway')),
                    flood_penalty=flood_vuln
                )
                self.G.add_edge(
                    e['from_city_id'], e['to_city_id'],
                    distance_miles          = float(e['distance_miles']),
                    travel_hours            = t_hours,
                    road_type               = str(e.get('road_type','US Highway')),
                    flood_vulnerable        = flood_vuln,
                    weight                  = t_hours,
                )
                added += 1

        print(f'  Graph built: {self.G.number_of_nodes()} nodes, {added} edges')

    def get_coords_array(self):
        """Return (N×2 array of [lat,lon], list of node IDs)."""
        nodes = self.node_list
        coords = np.array([[self.G.nodes[n]['lat'], self.G.nodes[n]['lon']] for n in nodes])
        return coords, nodes

    def node_weights_array(self):
        """Return normalized node weights as numpy array."""
        w = np.array([self.G.nodes[n]['node_weight'] for n in self.node_list])
        return w / w.sum()

    def weighted_objective(self, hub_ids: list) -> float:
        """
        Compute total weighted objective (core formula):
            Σ_i  w_i × min_d(hub_i)
        where w_i = node_weight, min_d = Haversine distance to nearest hub.
        Lower is better.
        """
        if not hub_ids:
            return float('inf')
        hub_coords = np.array([
            [self.G.nodes[h]['lat'], self.G.nodes[h]['lon']]
            for h in hub_ids if h in self.G.nodes
        ])
        total = 0.0
        for nid in self.node_list:
            d = self.G.nodes[nid]
            dists = np.array([haversine_miles(d['lat'],d['lon'],hc[0],hc[1]) for hc in hub_coords])
            total += d['node_weight'] * dists.min()
        return total


# ═════════════════════════════════════════════════════════════════════════════
# 2. HUB OPTIMIZER
# ═════════════════════════════════════════════════════════════════════════════
class HubOptimizer:
    """
    Places k emergency response hubs across US cities to minimize:
        Σ_i  ( population_i × water_risk_i × distance_i_to_nearest_hub )

    Three algorithms available:
      kmeans  — Weighted K-Means clustering.  O(n·k·iter).  Fast, good baseline.
      greedy  — Greedy p-Median.  O(k·n²).   Better coverage. Recommended.
      ilp     — Integer Linear Program.        Globally optimal. Slow for n>150.
    """

    def __init__(self, graph: FloodResponseGraph):
        self.graph       = graph
        self.G           = graph.G
        self.hubs        = []          # list of hub city_ids
        self.assignments = {}          # city_id → {hub_id, distance_miles, travel_hours}

    # ── Algorithm 1: Weighted K-Means ─────────────────────────────────────────
    def optimize_kmeans(self, k: int, random_state: int = 42) -> list:
        """
        Fit weighted K-Means on (lat, lon) coordinates.
        Each city is weighted by its node_weight (pop × risk).
        Centers are snapped to the nearest actual city.

        Steps:
          1. Extract [lat, lon] array for all nodes
          2. Compute sample_weight from node_weight (normalized)
          3. Fit KMeans with n_clusters=k
          4. For each centroid, find nearest city → hub candidate
          5. Deduplicate hub candidates
        """
        print(f'  [K-Means] k={k} ...')
        coords, nids = self.graph.get_coords_array()
        weights      = self.graph.node_weights_array()

        km = KMeans(n_clusters=k, random_state=random_state, n_init=25, max_iter=600)
        km.fit(coords, sample_weight=weights)

        hub_ids = []
        for center in km.cluster_centers_:
            dists = [haversine_miles(center[0],center[1],
                                     self.G.nodes[n]['lat'],
                                     self.G.nodes[n]['lon'])
                     for n in nids]
            best = nids[int(np.argmin(dists))]
            if best not in hub_ids:
                hub_ids.append(best)

        # Fill if duplicates reduced count
        if len(hub_ids) < k:
            remaining = [n for n in nids if n not in hub_ids]
            # Sort remaining by node_weight descending
            remaining.sort(key=lambda n: -self.G.nodes[n]['node_weight'])
            hub_ids += remaining[:k - len(hub_ids)]

        self.hubs = hub_ids
        self._assign_nodes()
        print(f'  ✓ K-Means: {len(self.hubs)} hubs placed')
        return self.hubs

    # ── Algorithm 2: Greedy p-Median ──────────────────────────────────────────
    def optimize_greedy(self, k: int) -> list:
        """
        Greedy facility location (p-Median approximation):
          1. Seed: place first hub at highest-weight node
          2. Iterate k-1 times: add the candidate that maximally
             reduces the weighted objective Σ w_i × min_dist_to_hub

        Approximation ratio: proven O(ln n) of optimal.
        Complexity: O(k × n²) — fine for n < 500 cities.
        """
        print(f'  [Greedy] k={k} ...')
        nids    = self.graph.node_list
        weights = {n: self.G.nodes[n]['node_weight'] for n in nids}
        coords  = {n: (self.G.nodes[n]['lat'], self.G.nodes[n]['lon']) for n in nids}

        # Seed: highest weighted node
        hub_ids = [max(weights, key=weights.get)]
        city0   = self.G.nodes[hub_ids[0]]
        print(f'    Seed hub: {city0["city"]}, {city0["state"]}')

        for step in range(1, k):
            cur_obj = self._fast_obj(hub_ids, nids, weights, coords)
            best_gain, best_node = -1.0, None

            for candidate in nids:
                if candidate in hub_ids:
                    continue
                trial  = hub_ids + [candidate]
                new_obj = self._fast_obj(trial, nids, weights, coords)
                gain    = cur_obj - new_obj
                if gain > best_gain:
                    best_gain = gain
                    best_node = candidate

            if best_node:
                hub_ids.append(best_node)
                c = self.G.nodes[best_node]
                print(f'    Hub {step+1:>2}: {c["city"]:<22}, {c["state"]}  '
                      f'(Δobj={best_gain:.2e})')

        self.hubs = hub_ids
        self._assign_nodes()
        print(f'  ✓ Greedy: {len(self.hubs)} hubs placed')
        return self.hubs

    def _fast_obj(self, hub_ids, nids, weights, coords):
        """Vectorized objective computation for greedy inner loop."""
        hub_arr = np.array([coords[h] for h in hub_ids])
        total   = 0.0
        for nid in nids:
            lat, lon = coords[nid]
            dists = np.array([haversine_miles(lat,lon,h[0],h[1]) for h in hub_arr])
            total += weights[nid] * dists.min()
        return total

    # ── Algorithm 3: ILP p-Median ─────────────────────────────────────────────
    def optimize_ilp(self, k: int, time_limit: int = 180) -> list:
        """
        Integer Linear Programming — p-Median formulation:

            Minimize  Σ_i Σ_j  w_i × d_ij × x_ij
            Subject to:
              Σ_j y_j = k              (exactly k hubs)
              Σ_j x_ij = 1  ∀i        (each city assigned to exactly one hub)
              x_ij ≤ y_j    ∀i,j      (can only assign to open hubs)
              x_ij, y_j ∈ {0,1}

        Variables:
          y_j = 1 if city j hosts a hub
          x_ij = 1 if city i is served by hub j
        """
        try:
            import pulp
        except ImportError:
            print('  ⚠ PuLP not installed. pip install pulp')
            print('  → Falling back to greedy')
            return self.optimize_greedy(k)

        print(f'  [ILP p-Median] k={k}, time_limit={time_limit}s ...')
        nids    = self.graph.node_list
        n       = len(nids)
        idx     = {nid: i for i,nid in enumerate(nids)}
        weights = [self.G.nodes[n]['node_weight'] for n in nids]
        coords  = [(self.G.nodes[n]['lat'], self.G.nodes[n]['lon']) for n in nids]

        # Distance matrix
        print(f'    Pre-computing {n}×{n} distance matrix ...')
        D = np.zeros((n,n))
        for i in range(n):
            for j in range(n):
                D[i,j] = haversine_miles(coords[i][0],coords[i][1],
                                          coords[j][0],coords[j][1])

        prob = pulp.LpProblem('p_median_flood', pulp.LpMinimize)
        x = [[pulp.LpVariable(f'x_{i}_{j}',cat='Binary') for j in range(n)] for i in range(n)]
        y = [pulp.LpVariable(f'y_{j}',cat='Binary') for j in range(n)]

        # Objective
        prob += pulp.lpSum(weights[i]*D[i][j]*x[i][j] for i in range(n) for j in range(n))
        # k hubs
        prob += pulp.lpSum(y[j] for j in range(n)) == k
        # Each city assigned to one hub
        for i in range(n):
            prob += pulp.lpSum(x[i][j] for j in range(n)) == 1
        # Assignment only to open hubs
        for i in range(n):
            for j in range(n):
                prob += x[i][j] <= y[j]

        solver = pulp.PULP_CBC_CMD(timeLimit=time_limit, msg=False)
        prob.solve(solver)

        hub_ids = [nids[j] for j in range(n) if pulp.value(y[j]) > 0.5]
        self.hubs = hub_ids
        self._assign_nodes()
        print(f'  ✓ ILP: {len(self.hubs)} hubs (status: {pulp.LpStatus[prob.status]})')
        return self.hubs

    # ── Node Assignment ────────────────────────────────────────────────────────
    def _assign_nodes(self):
        """Assign every city to its nearest hub using Haversine distance."""
        hub_coords = {h: (self.G.nodes[h]['lat'], self.G.nodes[h]['lon'])
                      for h in self.hubs if h in self.G.nodes}
        for nid in self.graph.node_list:
            d  = self.G.nodes[nid]
            best_hub, best_dist = None, float('inf')
            for hid, (hlat, hlon) in hub_coords.items():
                dist = haversine_miles(d['lat'], d['lon'], hlat, hlon)
                if dist < best_dist:
                    best_dist, best_hub = dist, hid
            self.assignments[nid] = {
                'hub_id':         best_hub,
                'distance_miles': round(best_dist, 2),
                'travel_hours':   round(travel_hours(best_dist), 3),
            }

    # ── Hub Statistics ─────────────────────────────────────────────────────────
    def get_hub_stats(self) -> pd.DataFrame:
        """
        Compute statistics for each hub:
          - cities covered, population served, coverage %
          - avg/max distance, avg response time
          - risk profile of covered area

        Returns pd.DataFrame sorted by population_served (desc).
        """
        if not self.hubs:
            raise RuntimeError('Run optimize_* first')

        total_pop = self.graph.master['population'].sum()
        records   = []

        for hid in self.hubs:
            hdata = self.G.nodes.get(hid, {})
            served = [(nid, self.assignments[nid])
                      for nid, a in self.assignments.items()
                      if a['hub_id'] == hid]
            pops   = [self.G.nodes[nid]['population'] for nid,_ in served]
            dists  = [a['distance_miles'] for _,a in served]
            risks  = [self.G.nodes[nid]['composite_water_risk'] for nid,_ in served]

            records.append({
                'hub_id':             hid,
                'hub_city':           hdata.get('city','?'),
                'hub_state':          hdata.get('state','?'),
                'hub_lat':            hdata.get('lat',0),
                'hub_lon':            hdata.get('lon',0),
                'hub_elevation_ft':   hdata.get('elevation_ft',0),
                'hub_region':         hdata.get('coast_region','?'),
                'cities_covered':     len(served),
                'population_served':  sum(pops),
                'coverage_pct':       round(sum(pops)/total_pop*100, 2),
                'avg_dist_miles':     round(np.mean(dists), 1) if dists else 0,
                'max_dist_miles':     round(max(dists), 1) if dists else 0,
                'avg_travel_hr':      round(travel_hours(np.mean(dists) if dists else 0), 3),
                'avg_area_risk':      round(np.mean(risks), 3) if risks else 0,
                'hub_risk':           round(hdata.get('composite_water_risk',0), 3),
                'hub_rank':           0,
            })

        df = (pd.DataFrame(records)
                .sort_values('population_served', ascending=False)
                .reset_index(drop=True))
        df['hub_rank'] = range(1, len(df)+1)
        return df

    def get_objective_value(self) -> float:
        return self.graph.weighted_objective(self.hubs)


# ═════════════════════════════════════════════════════════════════════════════
# 3. RESPONSE TIME PREDICTOR  (ML Model)
# ═════════════════════════════════════════════════════════════════════════════
class ResponseTimePredictor:
    """
    Gradient Boosting regressor to predict disaster-adjusted response times.

    Features:
      distance_to_hub, elevation_ft, composite_water_risk,
      flood_risk, hurricane_risk, storm_surge_risk, flash_flood_risk,
      population_density, median_income, hospitals, fire_stations,
      infrastructure_score, levee_protected, coast_proximity_mi

    Target: estimated response time in hours (from historical + modeled data)
    """

    FEATURES = [
        'distance_to_hub_miles', 'elevation_ft', 'composite_water_risk',
        'flood_risk', 'hurricane_risk', 'storm_surge_risk', 'flash_flood_risk',
        'population_density', 'median_income', 'hospitals', 'fire_stations',
        'infrastructure_score', 'levee_protected', 'coast_proximity_mi',
    ]

    def __init__(self):
        self.model   = GradientBoostingRegressor(
            n_estimators=250, max_depth=4, learning_rate=0.045,
            subsample=0.8, min_samples_leaf=3, random_state=42
        )
        self.scaler  = StandardScaler()
        self.trained = False

    def _build_features(self, master_df, assignments) -> pd.DataFrame:
        rows = []
        for _, r in master_df.iterrows():
            nid    = r['city_id']
            assign = assignments.get(nid, {'distance_miles': 200})
            rows.append({
                'distance_to_hub_miles':  assign.get('distance_miles', 200),
                'elevation_ft':           float(r.get('elevation_ft', 100)),
                'composite_water_risk':   float(r.get('composite_water_risk', 0.1)),
                'flood_risk':             float(r.get('flood_risk', 0.05)),
                'hurricane_risk':         float(r.get('hurricane_risk', 0.0)),
                'storm_surge_risk':       float(r.get('storm_surge_risk', 0.0)),
                'flash_flood_risk':       float(r.get('flash_flood_risk', 0.1)),
                'population_density':     float(r.get('population_density', 500)),
                'median_income':          float(r.get('median_income', 55000)),
                'hospitals':              float(r.get('hospitals', 2)),
                'fire_stations':          float(r.get('fire_stations', 5)),
                'infrastructure_score':   float(r.get('infrastructure_score', 0.6)),
                'levee_protected':        float(r.get('levee_protected', 0)),
                'coast_proximity_mi':     float(r.get('coast_proximity_mi', 200)),
            })
        return pd.DataFrame(rows)

    def _build_target(self, master_df, assignments, disaster='all') -> np.ndarray:
        """
        Construct synthetic target: response time in hours.
        Formula:
          t_i = base_time × (1 + risk_multiplier) × flood_road_penalty
        where base_time is driven by distance-to-hub.
        """
        targets = []
        risk_col = {
            'flood':'flood_risk','hurricane':'hurricane_risk',
            'storm_surge':'storm_surge_risk','flash_flood':'flash_flood_risk',
            'all':'composite_water_risk',
        }.get(disaster,'composite_water_risk')

        for _, r in master_df.iterrows():
            nid    = r['city_id']
            dist   = assignments.get(nid,{}).get('distance_miles', 150)
            risk   = float(r.get(risk_col, 0.1))
            infra  = float(r.get('infrastructure_score', 0.6))
            elev   = float(r.get('elevation_ft', 100))
            # base: distance / 55 mph avg speed
            base   = dist / 55.0
            # risk multiplier: high risk → roads may be flooded
            mult   = 1 + risk * 2.5 * (1 - infra * 0.5)
            # elevation bonus: lower elevation → harder to access
            elev_f = max(0.8, 1 + (0 - min(elev, 200)) / 500)
            t      = base * mult * elev_f + np.random.normal(0, 0.3)
            targets.append(max(0.25, t))
        return np.array(targets)

    def train(self, master_df, assignments, disaster='all') -> float:
        """Train model. Returns cross-validated R²."""
        X_df = self._build_features(master_df, assignments)
        y    = self._build_target(master_df, assignments, disaster)
        X    = self.scaler.fit_transform(X_df[self.FEATURES])
        self.model.fit(X, y)
        self.trained = True
        scores = cross_val_score(self.model, X, y, cv=5, scoring='r2')
        rmse   = mean_squared_error(y, self.model.predict(X)) ** 0.5
        print(f'  ML Model — R² (5-fold CV): {scores.mean():.3f} ± {scores.std():.3f}'
              f'  |  Train RMSE: {rmse:.3f} hrs')
        return scores.mean()

    def predict(self, master_df, assignments) -> pd.Series:
        if not self.trained:
            raise RuntimeError('Call train() first')
        X_df = self._build_features(master_df, assignments)
        X    = self.scaler.transform(X_df[self.FEATURES])
        preds = self.model.predict(X).clip(0.1)
        return pd.Series(preds, index=master_df.index)

    def feature_importance(self) -> pd.DataFrame:
        imp = self.model.feature_importances_
        return (pd.DataFrame({'feature': self.FEATURES, 'importance': imp})
                  .sort_values('importance', ascending=False)
                  .reset_index(drop=True))


# ═════════════════════════════════════════════════════════════════════════════
# 4. ZIP CODE LOOKUP
# ═════════════════════════════════════════════════════════════════════════════
class ZIPLookup:
    """
    Query interface for ZIP-code level information.
    Given a ZIP code, returns:
      • Location (lat/lon, city, state, elevation)
      • N nearest hubs with distances and response times
      • Local flood risk profile (all disaster types)
      • Coverage tier assessment
    """

    def __init__(self, zip_df, master_df, hub_stats, hub_ids, graph):
        self.zips      = zip_df.set_index('zip_code') if 'zip_code' in zip_df.columns else zip_df
        self.master    = master_df
        self.hub_stats = hub_stats
        self.hub_ids   = hub_ids
        self.graph     = graph

    def lookup(self, zip_code: str, n_nearest: int = 3) -> dict:
        """
        Full ZIP code lookup. Returns structured dict with all info.

        Parameters:
          zip_code  : 5-digit ZIP string
          n_nearest : how many nearest hubs to return

        Returns dict with keys:
          zip_info, nearest_hubs, risk_profile, coverage, raw_row
        """
        zc = str(zip_code).strip().zfill(5)

        # Find ZIP (exact or nearest numeric match)
        if zc in self.zips.index:
            row = self.zips.loc[zc]
        else:
            avail = np.array([int(z) for z in self.zips.index if z.isdigit()])
            nearest_z = str(avail[np.argmin(np.abs(avail - int(zc)))]).zfill(5)
            row = self.zips.loc[nearest_z]
            zc  = nearest_z

        zlat, zlon = float(row['latitude']), float(row['longitude'])

        # Find nearest hubs
        hub_dists = []
        for hid in self.hub_ids:
            if hid not in self.graph.G.nodes:
                continue
            hd   = self.graph.G.nodes[hid]
            dist = haversine_miles(zlat, zlon, hd['lat'], hd['lon'])
            hub_dists.append({
                'hub_id':         hid,
                'hub_city':       hd['city'],
                'hub_state':      hd['state'],
                'hub_region':     hd.get('coast_region','?'),
                'distance_miles': round(dist, 1),
                'travel_hours':   round(travel_hours(dist), 2),
            })
        hub_dists.sort(key=lambda x: x['distance_miles'])
        nearest_hubs = hub_dists[:n_nearest]

        # Risk profile from nearest city
        if len(self.master) > 0:
            city_dists = self.master.apply(
                lambda r: haversine_miles(zlat,zlon,r['latitude'],r['longitude']), axis=1)
            nc = self.master.iloc[city_dists.idxmin()]
            risk_profile = {
                'flood_risk':       float(nc.get('flood_risk',0)),
                'hurricane_risk':   float(nc.get('hurricane_risk',0)),
                'storm_surge_risk': float(nc.get('storm_surge_risk',0)),
                'flash_flood_risk': float(nc.get('flash_flood_risk',0)),
                'composite_risk':   float(nc.get('composite_water_risk',0)),
                'fema_flood_zone':  str(nc.get('fema_flood_zone','X')),
                'levee_protected':  int(nc.get('levee_protected',0)),
            }
        else:
            risk_profile = {}

        # Coverage tier
        nd = nearest_hubs[0]['distance_miles'] if nearest_hubs else 999
        if   nd < 50:  tier = ('Excellent', '✅', '#22c55e')
        elif nd < 100: tier = ('Good',      '🟡', '#eab308')
        elif nd < 200: tier = ('Fair',      '🟠', '#f97316')
        else:          tier = ('Poor',      '🔴', '#ef4444')

        return {
            'zip_code':       zc,
            'city':           str(row.get('city','Unknown')),
            'state':          str(row.get('state','?')),
            'latitude':       zlat,
            'longitude':      zlon,
            'population':     int(row.get('population',0)),
            'elevation_ft':   int(row.get('elevation_ft',0)),
            'flood_zone':     str(row.get('flood_zone','X')),
            'nearest_hubs':   nearest_hubs,
            'risk_profile':   risk_profile,
            'coverage_tier':  tier[0],
            'coverage_icon':  tier[1],
            'coverage_color': tier[2],
            'nearest_hub_dist_mi': nd,
        }


# ═════════════════════════════════════════════════════════════════════════════
# 5. FULL SCENARIO PIPELINE
# ═════════════════════════════════════════════════════════════════════════════
def run_scenario(master_df, edges_df, k, disaster_type, algorithm='greedy'):
    """
    End-to-end pipeline:
      build graph → optimize hubs → train ML predictor → compute stats

    Returns:
      graph, optimizer, hub_stats, predictor, master_out
    """
    print(f'\n{"─"*55}')
    print(f'  SCENARIO: k={k} | disaster={disaster_type} | algo={algorithm}')
    print(f'{"─"*55}')

    print('[1/4] Building flood response graph...')
    graph = FloodResponseGraph(master_df, edges_df, disaster_type=disaster_type)

    print('[2/4] Optimizing hub placement...')
    opt   = HubOptimizer(graph)
    if algorithm == 'kmeans':
        opt.optimize_kmeans(k)
    elif algorithm == 'ilp':
        opt.optimize_ilp(k)
    else:
        opt.optimize_greedy(k)

    obj = opt.get_objective_value()
    hub_stats = opt.get_hub_stats()
    print(f'\n  Weighted objective: {obj:,.0f}')

    print('[3/4] Training ML response time predictor...')
    predictor = ResponseTimePredictor()
    predictor.train(master_df, opt.assignments, disaster_type)

    print('[4/4] Attaching predictions to master dataset...')
    master_out = master_df.copy()
    master_out['predicted_response_hr']  = predictor.predict(master_df, opt.assignments)
    master_out['nearest_hub']            = master_df['city_id'].map(
        lambda c: opt.assignments.get(c,{}).get('hub_id','?'))
    master_out['dist_to_hub_miles']      = master_df['city_id'].map(
        lambda c: opt.assignments.get(c,{}).get('distance_miles',999))
    master_out['is_hub']                 = master_df['city_id'].isin(opt.hubs).astype(int)

    _print_results(hub_stats, master_out, obj)
    return graph, opt, hub_stats, predictor, master_out


def _print_results(hub_stats, master_out, obj):
    print(f'\n{"═"*65}')
    print('  HUB PLACEMENT RESULTS')
    print(f'{"═"*65}')
    print(f'  {"Rk":<4} {"City":<22} {"St":<4} {"Pop Served":>12} '
          f'{"Avg Dist":>9} {"Avg Resp":>9} {"Risk":>7}')
    print(f'  {"─"*4} {"─"*22} {"─"*4} {"─"*12} {"─"*9} {"─"*9} {"─"*7}')
    for _, r in hub_stats.iterrows():
        print(f'  {r["hub_rank"]:<4} {r["hub_city"]:<22} {r["hub_state"]:<4} '
              f'{r["population_served"]:>12,.0f} {r["avg_dist_miles"]:>8.1f}mi '
              f'{r["avg_travel_hr"]:>7.2f}hr  {r["avg_area_risk"]:>6.3f}')
    print(f'{"═"*65}')
    total = hub_stats['population_served'].sum()
    print(f'  Total pop served:   {total:>15,.0f}')
    print(f'  Weighted objective: {obj:>15,.0f}')
    if 'predicted_response_hr' in master_out.columns:
        print(f'  Avg response time:  {master_out["predicted_response_hr"].mean():>13.2f} hrs')
    print(f'{"═"*65}')


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Flood Hub Optimizer — Modeling')
    parser.add_argument('--hubs',      type=int, default=10)
    parser.add_argument('--disaster',  type=str, default='all',
                        choices=['all','flood','hurricane','storm_surge','flash_flood'])
    parser.add_argument('--algorithm', type=str, default='greedy',
                        choices=['kmeans','greedy','ilp'])
    parser.add_argument('--save',      action='store_true')
    args = parser.parse_args()

    master_path = os.path.join(DATA, 'master_cities.csv')
    edges_path  = os.path.join(DATA, 'edges.csv')
    zip_path    = os.path.join(DATA, 'zip_lookup.csv')

    if not os.path.exists(master_path):
        print('⚠ master_cities.csv not found. Run: python scripts/data_fetching.py')
        sys.exit(1)

    master_df = pd.read_csv(master_path)
    edges_df  = pd.read_csv(edges_path)
    zip_df    = pd.read_csv(zip_path, dtype={'zip_code':str})

    graph, opt, hub_stats, predictor, master_out = run_scenario(
        master_df, edges_df, args.hubs, args.disaster, args.algorithm
    )

    if args.save:
        hub_stats.to_csv(os.path.join(OUT,'tables','hub_stats.csv'), index=False)
        master_out.to_csv(os.path.join(OUT,'tables','city_assignments.csv'), index=False)
        predictor.feature_importance().to_csv(
            os.path.join(OUT,'tables','feature_importance.csv'), index=False)
        print('\n  Saved: outputs/tables/')

    # Demo ZIP lookup
    print('\n[Demo] ZIP lookup for 70116 (New Orleans, LA)')
    zl = ZIPLookup(zip_df, master_df, hub_stats, opt.hubs, graph)
    r  = zl.lookup('70116')
    print(f'  City: {r["city"]}, {r["state"]} | Elevation: {r["elevation_ft"]} ft')
    print(f'  Flood zone: {r["flood_zone"]} | Coverage: {r["coverage_tier"]}')
    print(f'  Nearest hub: {r["nearest_hubs"][0]["hub_city"]} '
          f'({r["nearest_hubs"][0]["distance_miles"]} mi, '
          f'{r["nearest_hubs"][0]["travel_hours"]} hrs)')
    print(f'  Composite water risk: {r["risk_profile"].get("composite_risk",0):.3f}')
