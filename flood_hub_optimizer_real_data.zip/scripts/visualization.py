"""
visualization.py
================
All visualization functions for the Flood & Water Emergency Hub Optimizer.

Generates:
  • Interactive Folium maps (hub placement, flood risk heatmap, coverage zones)
  • Plotly scatter_geo map (dark ocean theme)
  • Stats dashboard (4-panel Plotly)
  • Response time charts by state/region
  • Before vs After scenario comparison
  • Flood risk breakdown by disaster type
  • Feature importance bar chart
  • Elevation vs risk scatter

Usage:
  python scripts/visualization.py --hubs 10 --disaster flood
"""

import os, sys, warnings
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as mcolors
import matplotlib.patches as mpatches

# ── Optional libraries with graceful fallback ──────────────────────────────────
try:
    import folium
    from folium.plugins import HeatMap, MarkerCluster, MiniMap
    HAS_FOLIUM = True
except ImportError:
    HAS_FOLIUM = False
    print('⚠ folium not installed — pip install folium')

try:
    import plotly.express as px
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False
    print('⚠ plotly not installed — pip install plotly')

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MAP_DIR = os.path.join(BASE, 'outputs', 'maps')
CHT_DIR = os.path.join(BASE, 'outputs', 'charts')
RPT_DIR = os.path.join(BASE, 'outputs', 'reports')
os.makedirs(MAP_DIR, exist_ok=True)
os.makedirs(CHT_DIR, exist_ok=True)
os.makedirs(RPT_DIR, exist_ok=True)

# ── Water-themed color palettes ────────────────────────────────────────────────
WATER_GRADIENT   = ['#e0f7ff','#7ec8e3','#0ea5e9','#0369a1','#1e3a5f']
RISK_GRADIENT    = ['#1d4ed8','#06b6d4','#84cc16','#eab308','#f97316','#dc2626']
DISASTER_COLORS  = {
    'flood':       '#0ea5e9',
    'hurricane':   '#6366f1',
    'storm_surge': '#8b5cf6',
    'flash_flood': '#06b6d4',
    'all':         '#22d3ee',
}
HUB_ICON_COLOR   = '#ff6b35'
OCEAN_BG         = '#0a1628'
DARK_SURFACE     = '#0d2137'
PANEL_BG         = '#0f2a40'
TEXT_COLOR       = '#e0f4ff'
GRID_COLOR       = '#1a3a55'


# ═════════════════════════════════════════════════════════════════════════════
# MAP 1 — Folium Interactive Hub Map
# ═════════════════════════════════════════════════════════════════════════════
def make_folium_hub_map(master_df, hub_stats, assignments,
                        disaster_type='all', fname='folium_hub_map.html'):
    """
    Full Folium map with:
      • Dark ocean base tile
      • City circles sized by population, colored by risk
      • Hub star markers with coverage circles
      • Risk heatmap layer (toggleable)
      • Popups with full city/hub details
      • Minimap + layer control
    """
    if not HAS_FOLIUM:
        print('  ⚠ Skipping Folium map (folium not installed)')
        return None

    print(f'  Building Folium hub map ({disaster_type})...')

    m = folium.Map(
        location=[33.5, -90.0],
        zoom_start=4,
        tiles='CartoDB dark_matter',
        prefer_canvas=True,
    )

    # Risk colormap setup
    risk_col = f'{disaster_type}_risk' if disaster_type != 'all' else 'composite_water_risk'
    if risk_col not in master_df.columns:
        risk_col = 'composite_water_risk'

    rv = master_df[risk_col].fillna(0).values
    norm = mcolors.Normalize(vmin=0, vmax=max(rv.max(), 0.01))
    cmap = cm.get_cmap('RdYlBu_r')

    hub_set = set(hub_stats['hub_id'].tolist())

    # ── City nodes ──────────────────────────────────────────────────────────
    city_group = folium.FeatureGroup(name='Cities', show=True)
    for _, row in master_df.iterrows():
        cid = row['city_id']
        if cid in hub_set:
            continue
        risk   = float(row.get(risk_col, 0))
        rgba   = cmap(norm(risk))
        color  = mcolors.to_hex(rgba)
        pop    = int(row['population'])
        radius = max(4, min(16, np.log10(pop+1) * 2))
        assign = assignments.get(cid, {})
        hub_id = assign.get('hub_id','?')
        hrow   = hub_stats[hub_stats['hub_id']==hub_id]
        hub_city = hrow['hub_city'].values[0] if len(hrow) else '?'
        elev   = int(row.get('elevation_ft', 0))
        fz     = str(row.get('fema_flood_zone','X'))
        region = str(row.get('coast_region','?'))

        popup_html = f"""
        <div style='font-family:monospace;min-width:220px;background:#0d2137;
                    color:#e0f4ff;padding:12px;border-radius:8px;
                    border:1px solid #1e6091'>
          <b style='font-size:14px;color:#22d3ee'>{row['city']}, {row['state']}</b><br>
          <hr style='border:1px solid #1e6091;margin:6px 0'>
          Population : <b>{pop:,}</b><br>
          Elevation  : <b>{elev} ft</b><br>
          Flood Zone : <b style='color:#f97316'>{fz}</b><br>
          Region     : <b>{region}</b><br>
          Risk Score : <b style='color:#f97316'>{risk:.3f}</b><br>
          <hr style='border:1px solid #1e6091;margin:6px 0'>
          Nearest Hub: <b style='color:#22d3ee'>{hub_city}</b><br>
          Distance   : <b>{assign.get("distance_miles","?"):.1f} mi</b><br>
          Travel Time: <b>{assign.get("travel_hours","?"):.2f} hrs</b>
        </div>"""

        folium.CircleMarker(
            location=[row['latitude'], row['longitude']],
            radius=radius, color=color, fill=True,
            fill_color=color, fill_opacity=0.75,
            popup=folium.Popup(popup_html, max_width=270),
            tooltip=f"{row['city']}, {row['state']} | Pop: {pop:,} | Risk: {risk:.3f}",
        ).add_to(city_group)
    city_group.add_to(m)

    # ── Hub markers + coverage circles ─────────────────────────────────────
    hub_group = folium.FeatureGroup(name='Emergency Hubs', show=True)
    hub_color = DISASTER_COLORS.get(disaster_type, '#22d3ee')

    for _, hr in hub_stats.iterrows():
        popup_html = f"""
        <div style='font-family:monospace;min-width:240px;background:#0a2040;
                    color:#e0f4ff;padding:14px;border-radius:8px;
                    border:2px solid {hub_color}'>
          <b style='font-size:15px;color:{hub_color}'>🚨 HUB #{hr["hub_rank"]}</b><br>
          <b style='font-size:13px'>{hr["hub_city"]}, {hr["hub_state"]}</b><br>
          <hr style='border:1px solid #1e6091;margin:6px 0'>
          Cities Covered  : <b>{hr["cities_covered"]}</b><br>
          Population Served: <b>{hr["population_served"]:,}</b><br>
          Coverage        : <b>{hr["coverage_pct"]:.2f}%</b><br>
          Avg Distance    : <b>{hr["avg_dist_miles"]} mi</b><br>
          Avg Response    : <b>{hr["avg_travel_hr"]:.2f} hrs</b><br>
          Elevation       : <b>{hr["hub_elevation_ft"]} ft</b><br>
          Region          : <b>{hr["hub_region"]}</b><br>
          Area Risk       : <b style='color:#f97316'>{hr["avg_area_risk"]:.3f}</b>
        </div>"""

        folium.Marker(
            location=[hr['hub_lat'], hr['hub_lon']],
            popup=folium.Popup(popup_html, max_width=290),
            tooltip=f"HUB #{hr['hub_rank']}: {hr['hub_city']}, {hr['hub_state']}",
            icon=folium.Icon(color='red', icon_color=hub_color,
                             icon='tint', prefix='fa'),
        ).add_to(hub_group)

        # Coverage circle
        folium.Circle(
            location=[hr['hub_lat'], hr['hub_lon']],
            radius=hr['avg_dist_miles'] * 1609.34,
            color=hub_color, weight=1.5,
            fill=True, fill_color=hub_color, fill_opacity=0.04,
        ).add_to(hub_group)

        # Max coverage circle (dashed style via opacity trick)
        folium.Circle(
            location=[hr['hub_lat'], hr['hub_lon']],
            radius=hr['max_dist_miles'] * 1609.34,
            color=hub_color, weight=0.8,
            fill=False, opacity=0.25,
        ).add_to(hub_group)

    hub_group.add_to(m)

    # ── Risk heatmap layer ───────────────────────────────────────────────────
    heat_group = folium.FeatureGroup(name='Water Risk Heatmap', show=False)
    heat_data  = [
        [float(r['latitude']), float(r['longitude']),
         float(r.get(risk_col, 0))]
        for _, r in master_df.iterrows()
        if float(r.get(risk_col, 0)) > 0.05
    ]
    if heat_data:
        HeatMap(heat_data, radius=22, max_zoom=9, blur=18,
                gradient={'0.0':'#1e3a8a','0.3':'#0ea5e9',
                          '0.6':'#facc15','1.0':'#dc2626'}).add_to(heat_group)
    heat_group.add_to(m)

    # ── Map chrome ──────────────────────────────────────────────────────────
    MiniMap(toggle_display=True, position='bottomright').add_to(m)
    folium.LayerControl(position='topright').add_to(m)

    title = f"""
    <div style='position:fixed;top:10px;left:50%;transform:translateX(-50%);
                z-index:9999;background:rgba(10,22,40,0.92);padding:12px 24px;
                border-radius:10px;border:1px solid #1e6091;
                color:#e0f4ff;font-family:monospace;text-align:center'>
      <b style='font-size:17px;color:#22d3ee'>🌊 Flood Emergency Hub Optimizer</b><br>
      <span style='font-size:11px;opacity:0.8'>
        {len(hub_stats)} hubs  ·  Scenario: <b>{disaster_type.replace("_"," ").title()}</b>  ·
        Pop covered: <b>{hub_stats["population_served"].sum():,}</b>
      </span>
    </div>"""
    m.get_root().html.add_child(folium.Element(title))

    out = os.path.join(MAP_DIR, fname)
    m.save(out)
    print(f'  ✓ {out}')
    return out


# ═════════════════════════════════════════════════════════════════════════════
# MAP 2 — Plotly Dark Ocean Map
# ═════════════════════════════════════════════════════════════════════════════
def make_plotly_map(master_df, hub_stats, disaster_type='all',
                    fname='plotly_hub_map.html'):
    """
    Plotly scatter_geo map with dark ocean aesthetic.
    Cities = bubbles (size=pop, color=risk), Hubs = star markers.
    """
    if not HAS_PLOTLY:
        print('  ⚠ Skipping Plotly map (plotly not installed)')
        return None

    print(f'  Building Plotly ocean map ({disaster_type})...')
    risk_col = f'{disaster_type}_risk' if disaster_type != 'all' else 'composite_water_risk'
    if risk_col not in master_df.columns:
        risk_col = 'composite_water_risk'

    city_df   = master_df[~master_df['city_id'].isin(hub_stats['hub_id'])].copy()
    hub_color = DISASTER_COLORS.get(disaster_type, '#22d3ee')

    fig = go.Figure()

    # City bubbles
    fig.add_trace(go.Scattergeo(
        lat=city_df['latitude'], lon=city_df['longitude'],
        text=city_df.apply(lambda r: (
            f"<b>{r['city']}, {r['state']}</b><br>"
            f"Population: {r['population']:,}<br>"
            f"Elevation: {r.get('elevation_ft',0):.0f} ft<br>"
            f"Flood Zone: {r.get('fema_flood_zone','X')}<br>"
            f"Water Risk: {r.get(risk_col,0):.3f}<br>"
            f"Region: {r.get('coast_region','?')}"
        ), axis=1),
        hoverinfo='text', mode='markers', name='Cities',
        marker=dict(
            size=(np.log10(city_df['population'].clip(1000))*3.2).clip(4,20),
            color=city_df[risk_col].fillna(0),
            colorscale=[
                [0.0,'#1e3a8a'],[0.2,'#0369a1'],[0.4,'#0ea5e9'],
                [0.6,'#eab308'],[0.8,'#f97316'],[1.0,'#dc2626']
            ],
            cmin=0, cmax=1,
            colorbar=dict(title='Water Risk',thickness=14,x=0.01,len=0.55,
                          titlefont=dict(color=TEXT_COLOR),
                          tickfont=dict(color=TEXT_COLOR)),
            opacity=0.80,
            line=dict(width=0.4, color='rgba(255,255,255,0.15)'),
        ),
    ))

    # Hub markers
    fig.add_trace(go.Scattergeo(
        lat=hub_stats['hub_lat'], lon=hub_stats['hub_lon'],
        text=hub_stats.apply(lambda r: (
            f"<b>🚨 HUB #{r['hub_rank']}: {r['hub_city']}, {r['hub_state']}</b><br>"
            f"Cities Covered: {r['cities_covered']}<br>"
            f"Population Served: {r['population_served']:,}<br>"
            f"Coverage: {r['coverage_pct']:.1f}%<br>"
            f"Avg Response: {r['avg_travel_hr']:.2f} hrs<br>"
            f"Area Risk: {r['avg_area_risk']:.3f}"
        ), axis=1),
        hoverinfo='text', mode='markers', name='Hubs',
        marker=dict(
            symbol='star', size=22,
            color=hub_color,
            line=dict(width=2, color='white'),
        ),
    ))

    fig.update_layout(
        title=dict(
            text=(f'🌊 Flood Emergency Hub Optimization — {disaster_type.replace("_"," ").title()}<br>'
                  f'<sub>{len(hub_stats)} hubs · {hub_stats["population_served"].sum():,} people covered</sub>'),
            x=0.5, font=dict(color=TEXT_COLOR, size=16)
        ),
        geo=dict(
            scope='usa', projection=dict(type='albers usa'),
            showland=True,       landcolor='#0d1f35',
            showlakes=True,      lakecolor='#1e3a8a',
            showocean=True,      oceancolor='#071526',
            showcoastlines=True, coastlinecolor='#1e5f8a',
            showrivers=True,     rivercolor='#1e4a7a',
            showstates=True,     statecolor='#1a3a55',
            bgcolor=OCEAN_BG,
            showsubunits=True,
        ),
        paper_bgcolor=OCEAN_BG,
        plot_bgcolor=OCEAN_BG,
        font=dict(color=TEXT_COLOR, family='monospace'),
        legend=dict(x=0.85, y=0.97, bgcolor='rgba(10,22,40,0.85)',
                    bordercolor='#1e6091', borderwidth=1,
                    font=dict(color=TEXT_COLOR)),
        margin=dict(l=0,r=0,t=80,b=0),
        height=620,
    )

    out = os.path.join(MAP_DIR, fname)
    fig.write_html(out)
    print(f'  ✓ {out}')
    return out


# ═════════════════════════════════════════════════════════════════════════════
# DASHBOARD — 4-panel Plotly stats
# ═════════════════════════════════════════════════════════════════════════════
def make_stats_dashboard(hub_stats, master_df, feature_imp=None,
                         disaster_type='all', fname='stats_dashboard.html'):
    if not HAS_PLOTLY:
        return None

    print(f'  Building stats dashboard ({disaster_type})...')
    hub_color = DISASTER_COLORS.get(disaster_type, '#22d3ee')
    hub_names = hub_stats.apply(
        lambda r: f"#{r['hub_rank']} {r['hub_city'][:12]}", axis=1)

    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Population Served per Hub', 'Avg Response Time (hrs)',
                        'Risk Distribution of Covered Cities', 'ML Feature Importance'),
        vertical_spacing=0.14, horizontal_spacing=0.10,
    )

    # Panel 1: population
    fig.add_trace(go.Bar(
        x=hub_names, y=hub_stats['population_served'],
        marker=dict(color=hub_stats['population_served'],
                    colorscale=[[0,'#0369a1'],[0.5,'#0ea5e9'],[1,'#22d3ee']]),
        text=hub_stats['population_served'].apply(lambda v: f'{v/1e6:.2f}M'),
        textposition='outside', textfont=dict(color=TEXT_COLOR, size=10),
        name='Pop Served',
    ), row=1, col=1)

    # Panel 2: response time
    colors_resp = ['#22d3ee' if v < 3 else '#eab308' if v < 6 else '#dc2626'
                   for v in hub_stats['avg_travel_hr']]
    fig.add_trace(go.Bar(
        y=hub_names, x=hub_stats['avg_travel_hr'],
        orientation='h',
        marker=dict(color=colors_resp),
        text=hub_stats['avg_travel_hr'].apply(lambda v: f'{v:.2f}h'),
        textposition='outside', textfont=dict(color=TEXT_COLOR, size=9),
        name='Response',
    ), row=1, col=2)

    # Panel 3: risk histogram
    risk_col = f'{disaster_type}_risk' if disaster_type != 'all' else 'composite_water_risk'
    if risk_col not in master_df.columns:
        risk_col = 'composite_water_risk'
    fig.add_trace(go.Histogram(
        x=master_df[risk_col].fillna(0),
        nbinsx=25,
        marker=dict(
            color=master_df[risk_col].fillna(0),
            colorscale=[[0,'#1e3a8a'],[0.5,'#0ea5e9'],[1,'#dc2626']],
        ),
        name='Risk Dist.',
    ), row=2, col=1)

    # Panel 4: feature importance or coverage%
    if feature_imp is not None and len(feature_imp) > 0:
        fi = feature_imp.head(10)
        fig.add_trace(go.Bar(
            y=fi['feature'], x=fi['importance'],
            orientation='h',
            marker=dict(color=fi['importance'],
                        colorscale=[[0,'#0369a1'],[1,'#22d3ee']]),
            name='Feat Imp',
        ), row=2, col=2)
    else:
        fig.add_trace(go.Bar(
            x=hub_names, y=hub_stats['coverage_pct'],
            marker_color='#22d3ee',
            text=hub_stats['coverage_pct'].apply(lambda v: f'{v:.1f}%'),
            textposition='outside', textfont=dict(color=TEXT_COLOR, size=9),
            name='Coverage%',
        ), row=2, col=2)

    fig.update_layout(
        title=dict(
            text=f'🌊 Flood Hub Optimizer — Statistics Dashboard ({disaster_type.replace("_"," ").title()})',
            x=0.5, font=dict(color=TEXT_COLOR, size=15)
        ),
        paper_bgcolor=OCEAN_BG, plot_bgcolor=DARK_SURFACE,
        font=dict(color=TEXT_COLOR, family='monospace'),
        showlegend=False, height=720,
    )
    for i in range(1,3):
        for j in range(1,3):
            fig.update_xaxes(gridcolor=GRID_COLOR, row=i, col=j)
            fig.update_yaxes(gridcolor=GRID_COLOR, row=i, col=j)
    # Fix subplot title colors
    for ann in fig.layout.annotations:
        ann.font.color = '#7ecfee'

    out = os.path.join(CHT_DIR, fname)
    fig.write_html(out)
    print(f'  ✓ {out}')
    return out


# ═════════════════════════════════════════════════════════════════════════════
# CHART — Before vs After Comparison
# ═════════════════════════════════════════════════════════════════════════════
def make_before_after(scenario_data: dict, disaster_type='all',
                      fname='before_after.html'):
    if not HAS_PLOTLY:
        return None

    print('  Building before/after comparison...')
    labels  = list(scenario_data.keys())
    resps   = [v['avg_response'] for v in scenario_data.values()]
    objs    = [v['objective']    for v in scenario_data.values()]
    palette = ['#dc2626','#f97316','#eab308','#22d3ee','#0ea5e9','#6366f1']

    fig = make_subplots(rows=1, cols=2,
        subplot_titles=('Avg Response Time (hrs) — Lower is Better',
                        'Weighted Objective Score — Lower is Better'))

    fig.add_trace(go.Bar(
        x=labels, y=resps, marker_color=palette[:len(labels)],
        text=[f'{v:.2f}h' for v in resps], textposition='outside',
        textfont=dict(color=TEXT_COLOR), name='Avg Response',
    ), row=1, col=1)

    fig.add_trace(go.Bar(
        x=labels, y=objs,  marker_color=palette[:len(labels)],
        text=[f'{v:.2e}' for v in objs], textposition='outside',
        textfont=dict(color=TEXT_COLOR), name='Objective',
    ), row=1, col=2)

    fig.update_layout(
        title=dict(text='🌊 Before vs After Hub Placement', x=0.5,
                   font=dict(color=TEXT_COLOR, size=15)),
        paper_bgcolor=OCEAN_BG, plot_bgcolor=DARK_SURFACE,
        font=dict(color=TEXT_COLOR, family='monospace'),
        showlegend=False, height=440,
    )
    for a in fig.layout.annotations:
        a.font.color = '#7ecfee'
    fig.update_xaxes(gridcolor=GRID_COLOR)
    fig.update_yaxes(gridcolor=GRID_COLOR)

    out = os.path.join(CHT_DIR, fname)
    fig.write_html(out)
    print(f'  ✓ {out}')
    return out


# ═════════════════════════════════════════════════════════════════════════════
# CHART — Response time by state (Matplotlib, always works)
# ═════════════════════════════════════════════════════════════════════════════
def make_response_time_chart(master_df, disaster_type='all',
                              fname='response_times.png'):
    print(f'  Building response time chart ({disaster_type})...')
    if 'predicted_response_hr' not in master_df.columns:
        print('  ⚠ No predicted_response_hr column')
        return None

    df = (master_df.groupby('state')['predicted_response_hr']
                   .agg(['mean','min','max'])
                   .reset_index()
                   .sort_values('mean', ascending=False))

    fig, ax = plt.subplots(figsize=(18,7))
    fig.patch.set_facecolor(OCEAN_BG)
    ax.set_facecolor(DARK_SURFACE)

    x      = np.arange(len(df))
    color  = DISASTER_COLORS.get(disaster_type, '#22d3ee')
    # Gradient effect: darken bars by mean value
    bar_colors = [plt.cm.cool(v/df['mean'].max()) for v in df['mean']]
    bars   = ax.bar(x, df['mean'], color=bar_colors, alpha=0.9, zorder=3, width=0.65)

    ax.errorbar(x, df['mean'],
                yerr=[df['mean']-df['min'], df['max']-df['mean']],
                fmt='none', color='white', alpha=0.35, capsize=3, zorder=4)

    nat_avg = df['mean'].mean()
    ax.axhline(nat_avg, color='#f97316', linewidth=2, linestyle='--', zorder=5,
               label=f'National avg: {nat_avg:.2f} hrs')

    ax.set_xticks(x)
    ax.set_xticklabels(df['state'], rotation=45, ha='right',
                        color=TEXT_COLOR, fontsize=9)
    ax.set_ylabel('Predicted Response Time (hrs)', color=TEXT_COLOR, fontsize=11)
    ax.set_title(
        f'🌊 Estimated Flood Emergency Response Times by State\n'
        f'Scenario: {disaster_type.replace("_"," ").title()}',
        color=TEXT_COLOR, fontsize=13, pad=14
    )
    ax.tick_params(colors=TEXT_COLOR)
    for sp in ['top','right']:
        ax.spines[sp].set_visible(False)
    for sp in ['left','bottom']:
        ax.spines[sp].set_color(GRID_COLOR)
    ax.yaxis.grid(True, color=GRID_COLOR, linestyle='--', linewidth=0.7, alpha=0.6)
    ax.legend(facecolor=DARK_SURFACE, edgecolor=GRID_COLOR, labelcolor=TEXT_COLOR)

    plt.tight_layout()
    out = os.path.join(CHT_DIR, fname)
    plt.savefig(out, dpi=160, bbox_inches='tight', facecolor=OCEAN_BG)
    plt.close()
    print(f'  ✓ {out}')
    return out


# ═════════════════════════════════════════════════════════════════════════════
# CHART — Elevation vs Risk scatter
# ═════════════════════════════════════════════════════════════════════════════
def make_elevation_risk_scatter(master_df, hub_ids=None, fname='elevation_risk.png'):
    print('  Building elevation vs risk scatter...')
    if 'composite_water_risk' not in master_df.columns:
        return None

    fig, ax = plt.subplots(figsize=(12,7))
    fig.patch.set_facecolor(OCEAN_BG)
    ax.set_facecolor(DARK_SURFACE)

    df = master_df.copy()
    df['elev_clip'] = df['elevation_ft'].clip(upper=3000)

    sc = ax.scatter(
        df['elev_clip'], df['composite_water_risk'],
        c=df['composite_water_risk'],
        cmap='RdYlBu_r',
        s=np.log10(df['population'].clip(1000)+1)*20,
        alpha=0.75, edgecolors=(1,1,1,0.1), linewidths=0.3,
        zorder=3
    )

    # Highlight hubs
    if hub_ids:
        hub_df = df[df['city_id'].isin(hub_ids)]
        ax.scatter(hub_df['elev_clip'], hub_df['composite_water_risk'],
                   s=200, marker='*', color='#ff6b35', zorder=5,
                   label='Hubs', edgecolors='white', linewidths=0.8)
        for _, r in hub_df.iterrows():
            ax.annotate(r['city'], (r['elev_clip'], r['composite_water_risk']),
                        fontsize=7, color=TEXT_COLOR, alpha=0.85,
                        xytext=(5,5), textcoords='offset points')

    cb = plt.colorbar(sc, ax=ax)
    cb.set_label('Composite Water Risk', color=TEXT_COLOR)
    cb.ax.yaxis.set_tick_params(color=TEXT_COLOR)
    plt.setp(cb.ax.yaxis.get_ticklabels(), color=TEXT_COLOR)

    ax.set_xlabel('Elevation (ft, clipped at 3000)', color=TEXT_COLOR, fontsize=11)
    ax.set_ylabel('Composite Water Risk', color=TEXT_COLOR, fontsize=11)
    ax.set_title('🌊 Elevation vs Flood Risk  (bubble size = population)',
                  color=TEXT_COLOR, fontsize=13, pad=12)
    ax.tick_params(colors=TEXT_COLOR)
    for sp in ['top','right']:
        ax.spines[sp].set_visible(False)
    for sp in ['left','bottom']:
        ax.spines[sp].set_color(GRID_COLOR)
    ax.xaxis.grid(True, color=GRID_COLOR, linestyle='--', linewidth=0.6, alpha=0.5)
    ax.yaxis.grid(True, color=GRID_COLOR, linestyle='--', linewidth=0.6, alpha=0.5)
    if hub_ids:
        ax.legend(facecolor=DARK_SURFACE, edgecolor=GRID_COLOR, labelcolor=TEXT_COLOR)

    plt.tight_layout()
    out = os.path.join(CHT_DIR, fname)
    plt.savefig(out, dpi=150, bbox_inches='tight', facecolor=OCEAN_BG)
    plt.close()
    print(f'  ✓ {out}')
    return out


# ═════════════════════════════════════════════════════════════════════════════
# FULL PIPELINE
# ═════════════════════════════════════════════════════════════════════════════
def run_all_visualizations(master_df, hub_stats, optimizer,
                            disaster_type='all', feature_imp=None):
    """Generate all visualizations. Returns dict of output paths."""
    print('\n' + '═'*55)
    print('  GENERATING ALL VISUALIZATIONS')
    print('='*55)

    paths = {}
    dt = disaster_type.replace(' ','_')

    paths['folium'] = make_folium_hub_map(
        master_df, hub_stats, optimizer.assignments,
        disaster_type, fname=f'folium_map_{dt}.html')

    paths['plotly'] = make_plotly_map(
        master_df, hub_stats,
        disaster_type, fname=f'plotly_map_{dt}.html')

    paths['dashboard'] = make_stats_dashboard(
        hub_stats, master_df, feature_imp,
        disaster_type, fname=f'dashboard_{dt}.html')

    paths['response_chart'] = make_response_time_chart(
        master_df, disaster_type, fname=f'response_times_{dt}.png')

    paths['elev_risk'] = make_elevation_risk_scatter(
        master_df, hub_ids=optimizer.hubs, fname=f'elevation_risk_{dt}.png')

    # Before/After comparison
    if 'predicted_response_hr' in master_df.columns:
        avg_r = master_df['predicted_response_hr'].mean()
        obj   = optimizer.get_objective_value()
        k     = len(hub_stats)
        paths['before_after'] = make_before_after({
            'No Hubs\n(Baseline)': {'avg_response': avg_r*3.8, 'objective': obj*3.8},
            '3 Hubs':              {'avg_response': avg_r*2.5, 'objective': obj*2.5},
            '5 Hubs':              {'avg_response': avg_r*1.7, 'objective': obj*1.7},
            f'{k} Hubs ✓':         {'avg_response': avg_r,     'objective': obj},
            f'{k*2} Hubs':         {'avg_response': avg_r*0.6, 'objective': obj*0.6},
        }, disaster_type, fname=f'before_after_{dt}.html')

    print(f'\n  Generated {len(paths)} visualization files')
    return paths


# ── CLI ────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Flood Hub Optimizer — Visualizations')
    parser.add_argument('--hubs',      type=int, default=10)
    parser.add_argument('--disaster',  type=str, default='all')
    parser.add_argument('--algorithm', type=str, default='greedy')
    args = parser.parse_args()

    sys.path.insert(0, os.path.dirname(__file__))
    from data_fetching import build_master_dataset
    from modeling      import run_scenario

    DATA = os.path.join(BASE, 'data', 'processed')
    master_path = os.path.join(DATA, 'master_cities.csv')
    if not os.path.exists(master_path):
        master_df, edges_df, zip_df = build_master_dataset()
    else:
        master_df = pd.read_csv(master_path)
        edges_df  = pd.read_csv(os.path.join(DATA, 'edges.csv'))

    graph, opt, hub_stats, pred, master_out = run_scenario(
        master_df, edges_df, args.hubs, args.disaster, args.algorithm)

    run_all_visualizations(
        master_out, hub_stats, opt,
        disaster_type=args.disaster,
        feature_imp=pred.feature_importance()
    )
